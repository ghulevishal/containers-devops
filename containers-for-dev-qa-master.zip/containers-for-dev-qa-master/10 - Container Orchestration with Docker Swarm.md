### 9.1 How to create `Docker swarm` using `manager` and `worker` node?
### 9.1 How to create services in `Docker Swarm`?
### 9.1 How to create replicas of service in `Docker swarm`?
### 9.1 How to remove services from `Docker Swarm`?
### 9.2 How to deploy RSVP application using `Docker swarm`?
### 9.3 How to reflect changes made in source code of application to deployed application in `Docker swarm`?
### 9.4 How to deploy RSVP appliaction using `Docker stack` with `docker-compose.yml` and `docker-stack.yaml` in `Docker swarm`?

## 10.1 Create Docker Swarm with `Manager` and `Worker` nodes
- 1. Create 2 Droplet at Digital ocean with name  `manager` and `worker` respectively.
- 2. Install Docker on both `manager` and `worker` Droplets. For more help regarding Docker installation please visit [here](https://github.com/vishalcloudyuga/containers-for-all/blob/master/4-container_runtimes.md) 
- 3. At `manager` droplet's terminal initialize docker swarm with its IP
```
$ docker swarm init
Error response from daemon: could not choose an IP address to advertise since this system has multiple addresses on interface eth0 (159.203.126.194 and 10.17.0.5) - specify one with --advertise-addr

$ docker swarm init --advertise-addr 159.203.126.194
Swarm initialized: current node (mggbt9wehgkwpffvq2y8h3939) is now a manager.

To add a worker to this swarm, run the following command:

    docker swarm join \
    --token SWMTKN-1-60fbvb49p9onwomvklcszkq5sl2n9xg4y17f541p27ik7yv7tz-2yhcdx45vibendax9psin3zyg \
    159.203.126.194:2377

To add a manager to this swarm, run 'docker swarm join-token manager' and follow the instructions.

```
- 4. Copy the the command shown to jon swarm and goto `worker` terminal.
```
$ docker swarm join \
    --token SWMTKN-1-60fbvb49p9onwomvklcszkq5sl2n9xg4y17f541p27ik7yv7tz-2yhcdx45vibendax9psin3zyg \
    159.203.126.194:2377
```
- 5. Goto `manager` terminal and execute `$ docker info | less` will show the active status of swarm. 
```
$ docker info | less
.
.
Swarm: active
 NodeID: vds37fdk8s3odjnrygbk2y7g1
 Is Manager: true
 ClusterID: po88seygi0n1zxsm9pkyiihxi
 Managers: 1
 Nodes: 2
 '
 '
 '
```
- 6. Now create the servise at `manager` node Terminal.
```
$  docker service create alpine ping 8.8.8.8
t46ik0htohxi2zq1k7pxzn6wf
```
- 7. List the running services at `manager` node.
```
$ docker service ls
ID            NAME                 MODE        REPLICAS  IMAGE
t46ik0htohxi  affectionate_easley  replicated  1/1       alpine:latest
```
- 8. Detail of the service with ID. Lets use the ID of service shown in above output. 
```
$ docker service ps t46ik0htohxi
ID            NAME                   IMAGE          NODE     DESIRED STATE  CURRENT STATE          ERROR  PORTS
taydx2ss8gkl  affectionate_easley.1  alpine:latest  manager  Running        Running 2 minutes ago
```
- 9. Creating the Replicas of the service by using its name.
```
$ docker service update affectionate_easley --replicas 4
affectionate_easley
```
- 10. Checking the replicas of service by using its name.
```
$ docker service ps affectionate_easley
ID            NAME                   IMAGE          NODE     DESIRED STATE  CURRENT STATE               ERROR  PORTS
taydx2ss8gkl  affectionate_easley.1  alpine:latest  manager  Running        Running 6 minutes ago
bknvn9v0nzh2  affectionate_easley.2  alpine:latest  worker   Running        Running about a minute ago
xclzhpvgdvfw  affectionate_easley.3  alpine:latest  manager  Running        Running about a minute ago
vd9mp9z24n7a  affectionate_easley.4  alpine:latest  worker   Running        Running about a minute ago
```
- 11. List of running containers on `manager` node.
```
$ docker container ls 
CONTAINER ID        IMAGE                                                                            COMMAND             CREATED             STATUS              PORTS               NAMES
b9ab74fbe2a2        alpine@sha256:dfbd4a3a8ebca874ebd2474f044a0b33600d4523d03b0df76e5c5986cb02d7e8   "ping 8.8.8.8"      2 minutes ago       Up 2 minutes                            affectionate_easley.3.xclzhpvgdvfwynsczfw5gz1lb
9619505b719c        alpine@sha256:dfbd4a3a8ebca874ebd2474f044a0b33600d4523d03b0df76e5c5986cb02d7e8   "ping 8.8.8.8"      7 minutes ago       Up 7 minutes                            affectionate_easley.1.taydx2ss8gkllui33oa4n86r0

```
- 12. Now goto `worker` terminal. check the running container runnin on the `worker` node. and remove one of the running containers.
```
$ docker container ls
CONTAINER ID        IMAGE                                                                                                                                                                      COMMAND             CREATED             STATUS                                                                                                        PORTS               NAMES
578a269fcf2a        alpine@sha256:dfbd4a3a8ebca874ebd2474f044a0b33600d4523d03b                                                                                          0df76e5c5986cb02d7e8   "ping 8.8.8.8"      4 minutes ago       Up 4 minutes                                                                                                                      affectionate_easley.2.bknvn9v0nzh2u5rrpmr5h0pse
d59fcaa7b7d0        alpine@sha256:dfbd4a3a8ebca874ebd2474f044a0b33600d4523d03b                                                                                          0df76e5c5986cb02d7e8   "ping 8.8.8.8"      4 minutes ago       Up 4 minutes                                                                                                                      affectionate_easley.4.vd9mp9z24n7a8nleszknzitw1
$ docker container rm -f d59fcaa7b7d0
d59fcaa7b7d0
```
- 13. Now goto `manager` terminal and check the service list.

```
$ docker service ls
ID            NAME                 MODE        REPLICAS  IMAGE

t46ik0htohxi  affectionate_easley  replicated  4/4       alpine:latest
```
- 14. Remove the service from `manager` node.
```
$ docker service rm affectionate_easley
affectionate_easley

```
- 15.Goto `worker` terminal ad you can see no running container is present.
```
$ docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES
```

## 10.2 run RSVP application using the Docker swarm. 
- 1. At `manager` terminal create a `Network` with name `rsvpnet`.
```
$ docker network create --driver overlay rsvpnet
kqx9an9gk7699vihgdyjwp324
```
- 2. Crete the service of MONGODB DATABSE with name `mongod` using `rsvpnet` network and `mongo:3.3` image.
```
$ docker service create --name mongodb -e MONGODB_DATABASE=rsvpdata --network=rsvpnet mongo:3.3
8wig4ei59ujzj90a992smmc2j
```
- 3. List down the running services.
```
$ docker service ls
ID            NAME     MODE        REPLICAS  IMAGE
8wig4ei59ujz  mongodb  replicated  1/1       mongo:3.3
```
- 4. Check the service named `mongodb`
```
$ docker service ps mongodb
ID            NAME       IMAGE      NODE     DESIRED STATE  CURRENT STATE               ERROR  PORTS
ydev3rv9i1uk  mongodb.1  mongo:3.3  manager  Running        Running about a minute ago
```
- 5. Create the service `web` with `mongodb` service, `rsvpnet` network and `teamcloudyuga/rsvpapp:mooc` image
```
$ docker service create --name web -e MONGODB_HOST=mongodb --publish 5000 --network=rsvpnet teamcloudyuga/rsvpapp:mooc
sv8p79m3h57yg58gs4qjigrcx

$ docker service ps web
ID            NAME   IMAGE                       NODE    DESIRED STATE  CURRENT STATE           ERROR  PORTS
foywo1bynsbr  web.1  teamcloudyuga/rsvpapp:mooc  worker  Running        Running 55 seconds ago
```
- 6. At `manager` terminal `docker service inspect web | less` command shows at which port our service is running. Under `"Ports"` section it gives `"PublishedPort"`, this is the port at which RSVP application is running.
```
$ docker service inspect web | less
...
 "Ports": [
                {
                    "Protocol": "tcp",
                    "TargetPort": 5000,
                    "PublishedPort": 30000,
                    "PublishMode": "ingress"
                }
...
```
- 7. Goto your browser window and enter IP address of `manager` and `worker` droplet with above `PublishedPort`. You will see RSVP app is running on both the addresses of `manager` node and `worker` node.  

- 8. Lets create 2 replicas of `web` service at `manager` terminal.
```
$ docker service update web --replicas 2
web

$ docker service ps web
ID            NAME   IMAGE                       NODE     DESIRED STATE  CURRENT STATE           ERROR  PORTS
ikqppvgtogwk  web.1  teamcloudyuga/rsvpapp:mooc  worker   Running        Running 18 minutes ago
nfrnigkt93bd  web.2  teamcloudyuga/rsvpapp:mooc  manager  Running        Running 45 seconds ago

```
- 9. Now goto IP addresses of both `manager` and `worker` droplets with `PublishedPort`. If you try to refresh the page you can see name of host is changing.

## 10.3 Docker Swarm rolling updates
- 1. Lets clone the `RSVP` git repository. Goto `rsvpapp`>`templates`>`profile.html` and make change at 20th  Replace `Name` with `Your Name` and at 24th line replace `Email` by `Your Email` and save it.
- 2. In this rsvpapp folder Build new image and push it to the `Docker Hub`

- 3. Now go to `manager` terminal and update the `web` service with recently created image.
```
$ docker service update --image nkhare/rsvpapp:mooc_v1 --update-delay 30s web 
```
- 4. Under the `docker service ps web` command you can see current status of service `web`, on which image the `web` service is running.
```
$ docker service ps web
ID            NAME       IMAGE                       NODE     DESIRED STATE  CURRENT STATE                ERROR  PORTS
p4qle0sexx53  web.1      nkhare/rsvpapp:mooc_v1      Worker   Running        Running about a minute ago
2gyiwwrkgf7n   \_ web.1  teamcloudyuga/rsvpapp:mooc  Worker   Shutdown       Shutdown about a minute ago
y7dci9mnkk4w  web.2      nkhare/rsvpapp:mooc_v1      Manager  Running        Running 25 seconds ago
jdn1ga7xksax   \_ web.2  teamcloudyuga/rsvpapp:mooc  Manager  Shutdown       Shutdown 26 seconds ago
```
- 5. Goto browser and refresh page and you will see changes we have made in `profile.html` in step 1 are replicated here.

## 10.4 Docker stack
A stack is a collection of services that make up an application in a specific environment. A stack file is a file in YAML format, similar to a docker-compose.yml file, that defines one or more services. Stacks are a convenient way to automatically deploy multiple services that are linked to each other, without needing to define each one separately.

- 1. Check the list of running service on `manager`. You can remove running services by `$ docker service rm`
```
$ docker service ls
ID  NAME  MODE  REPLICAS  IMAGE
```
- 2. At `manager` terminal create directory and get `docker-compose.yml`
```
$ mkdir rsvpapp
$ cd /rsvpapp
$ wget https://raw.githubusercontent.com/cloudyuga/rsvpapp/master/docker-compose.yml
```
- 3. Edit `docker-compose.yml` and in line 1 change version 2 to 3.
```
version: '3'
services:
 mongodb:
   image: mongo:3.3
   expose:
     - "27017"
   volumes:
     - db_data:/data/db
   environment:
    MONGODB_DATABASE: rsvpdata
   networks:
    - rsvpnet

 web:
   image: teamcloudyuga/rsvpapp:mooc
   ports:
    - "5000:5000"
   environment:
    MONGODB_HOST: mongodb
    LINK: http://www.meetup.com/cloudyuga/
    TEXT1: CloudYuga
    TEXT2: Garage RSVP!
    LOGO: https://raw.githubusercontent.com/cloudyuga/rsvpapp/master/static/cloudyuga.png
    COMPANY: CloudYuga Technology Pvt. Ltd.
   networks:
    - rsvpnet

networks:
  rsvpnet:

volumes:
   db_data:

```
- 4. Deploy the RSVP application using the `Docker stack` using `docker-compose.yml` file.
```
$ docker stack deploy -c docker-compose.yml myrsvpapp
Ignoring deprecated options:

expose: Exposing ports is unnecessary - services on the same network can access each other's containers on any port.

Creating network myrsvpapp_rsvpnet
Creating service myrsvpapp_mongodb
Creating service myrsvpapp_web

$ docker stack services myrsvpapp
ID            NAME               MODE        REPLICAS  IMAGE
jle2brzi2nxe  myrsvpapp_web      replicated  1/1       teamcloudyuga/rsvpapp:mooc
udbwdmsnj8wk  myrsvpapp_mongodb  replicated  1/1       mongo:3.3

```
Goto the browser and check at 5000 port of both `worker` and `manager` droplet's IP address. RSVP application is running.

- 5. Lets modify the `docker-compose.yml` as below
```
version: '3'
services:
 mongodb:
   image: mongo:3.3
   expose:
     - "27017"
   volumes:
     - db_data:/data/db
   environment:
    MONGODB_DATABASE: rsvpdata
   networks:
    - rsvpnet

 web:
   image: nkhare/rsvpapp:mooc
   ports:
    - "5000:5000"
   environment:
    MONGODB_HOST: mongodb
    LINK: http://www.meetup.com/cloudyuga/
    TEXT1: CloudYuga
    TEXT2: Garage RSVP!
    LOGO: https://raw.githubusercontent.com/cloudyuga/rsvpapp/master/static/cloudyuga.png
    COMPANY: CloudYuga Technology Pvt. Ltd.
   deploy:
     replicas: 3
     update_config:
       parallelism: 2
       delay: 30s
   networks:
    - rsvpnet

 visualizer:
    image: dockersamples/visualizer:stable
    ports:
      - "8080:8080"
    stop_grace_period: 1m30s
    volumes:
      - "/var/run/docker.sock:/var/run/docker.sock"
    deploy:
      placement:
        constraints: [node.role == manager]

networks:
  rsvpnet:

volumes:
   db_data:
```

- 6. Now run following command that will update the services
```
$ docker stack deploy -c docker-compose.yml myrsvpapp
```
In browser we can see at `8080` port of both `manager` and `worker` droplets IP address `Docker visualizer` is running. Docker visualizer shows the services running by the `Docker Stack`.

- 7. Lets make docker-stack.yaml file. And deploy application using the `Docker stack` and `docker-stack.yaml` file
```
$ mv docker-compose.yml docker-stack.yaml
$ docker stack deploy -c docker-stack.yaml myrsvpapp
Ignoring deprecated options:

expose: Exposing ports is unnecessary - services on the same network can access each other's containers on any port.

Creating network myrsvpapp_rsvpnet
Creating service myrsvpapp_mongodb
Creating service myrsvpapp_web


$ docker service ps myrsvpapp_web
ID            NAME                 IMAGE                       NODE     DESIRED STATE  CURRENT STATE                ERROR  PORTS
lhhm1zw641il  myrsvpapp_web.1      nkhare/rsvpapp:mooc         manager  Running        Running 2 minutes ago
l996nk5mmgvx   \_ myrsvpapp_web.1  nkhare/rsvpapp:mooc         worker   Shutdown       Shutdown 2 minutes ago
yser6wv6ip4m   \_ myrsvpapp_web.1  teamcloudyuga/rsvpapp:mooc  worker   Shutdown       Shutdown 10 minutes ago
jc89yzvexkvq  myrsvpapp_web.2      nkhare/rsvpapp:mooc         worker   Running        Running about a minute ago
wxzoz4spviz8   \_ myrsvpapp_web.2  nkhare/rsvpapp:mooc         worker   Shutdown       Shutdown about a minute ago
2u8v05tnixan  myrsvpapp_web.3      nkhare/rsvpapp:mooc         manager  Running        Running 2 minutes ago
ug95205dl6rx   \_ myrsvpapp_web.3  nkhare/rsvpapp:mooc         manager  Shutdown       Shutdown 2 minutes ago

```
- 8. Check at docker visualizer in browser it will show running services.
- 9. Lets Stop the applicaton and remove services using `Docker-stack` 
```
$ docker stack down myrsvpapp
Removing service myrsvpapp_visualizer
Removing service myrsvpapp_web
Removing service myrsvpapp_mongodb
Removing network myrsvpapp_default
Removing network myrsvpapp_rsvpnet

```

## References
#### 1. https://docs.docker.com/swarm/overview/
#### 2. https://docs.docker.com/docker-cloud/apps/stacks/
#### 3. https://docs.docker.com/docker-cloud/apps/stack-yaml-reference/

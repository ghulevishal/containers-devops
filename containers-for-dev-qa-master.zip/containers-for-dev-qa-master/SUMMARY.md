# Summary

* [Introduction](README.md)
* [Docker essentials for Dev and QA](1-essentials.md)
* [Getting familiar with sample application](2.sample_app.md)
* [Deploying sample application with Docker Compose](3.docker_compose_sample_app.md)
* [Setting up Development Environment](4.setting_up_dev_environment.md)
* [Introduction to Jenkins](5.jenkins.md)
* [Continuous Integration and Deployment](6.ci_cd_jenkins.md)
* [End to Wnd Workflow for Developers](7.end_to_end_workflow.md)
* [Service Dicovery, Reverse Proxy and Load Balancing](8.service_discovery_load_balancing.md)
* [Microservices](9.micoservices.md)
* [Introduction to Container Orchstration](10.container_orchestration_basics.md)
* [Docker Swarm](11.docker_swarm.md
* [Case Study # 1 - Openshiftv3](12.case_study_1_openshiftv3.md)
* [Case Study # 2 - Shippable](13.case_study_2_shippable.md)

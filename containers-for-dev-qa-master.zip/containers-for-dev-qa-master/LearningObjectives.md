## Pre-requisite
- Working knowledge of Docker, Git
- Basic understanding of Cloud

## Chapter 1 - Installing Docker 
- Learn how to install Docker on Linux, Windows and Mac
- Learn how to verify the installation

## Chapter 2 - Docker Essentials
- Review of Docker basics
- Review of Docker architecture,  basic container and image commands
- Review of Docker networking and volumes 
- Review of Dockerfiles, Docker Machine and Docker Compose

## Chapter 3 - Becoming familiar with sample applications
- Quick introduction to Python's Flask framework
- Learn how to create a simple "Hello World" web application with Flask
- Learn about sample RSVP application

## Chapter 4 - Deploying a sample multi-application with Docker Compose
- Learn how to deploy a sample RSVP application with Docker Compose
- Learn how to connect to a remote Docker daemon and deploy the application with Docker Compose

## Chapter 5 - Setting up the Development environment
- Learn how to install `Visual Studio Code` (vscode)
- Learn how use `Visual Studio Code` for our sample application
- Learn how to use `Visual Studio Code` to deploy containers with Docker

## Chapter 6 - Jenkins Overview
- Overview of Jenkins
- Learn how to create Jenkins slaves and run a job inside them
- Learn how to install Jenkins plugins 
- Learn about the Jenkins pipeline

## Chapter 7 - Docker containers as Jenkins Slaves
- Learn how to create a dynamic slave with Docker
- Learn how to run tests inside the dynamically provisioned slave

## Chapter 8 - CI/CD with Jenkins - Setting up staging environment
- Learn how to use the Jenkins pipeline features to create a build, test and deploy stages in a pipeline
- Learn how create a pipeline for our sample application
- Learn how to connect to a remote Docker daemon securely from Jenkins pipeline

## Chapter 9 - Introduction Container Orchestration
- Learn about general concepts of container orchestrators
- Learn about different building blocks of any container orchestrator

## Chapter 10 - Container Orchestration with Docker Swarm
- Learn how to create Docker Swarm cluster 
- Learn how to deploy sample application on Docker Swarm 
- Learn how to scale the sample application with Docker Swarm
- Learn how to do rolling updates for sample application

## Chapter 11 - Service Discovery, Reverse Proxy and Load Balancing
- Learn about Service Discovery, Reverse Proxy and Load Balancing
- Learn how to use Nginx for Reverse Proxy and Load Balancin

## Chapter 12 - The end-to-end workflow of an application with containers
- Learn about end to end workflow of application, from development to production
- Learn how to link IDE, Jenkins and Container Orchestrator 

## Chapter 13 - Introduction to Mircoservices
- Learn about Microservices 
- Learn about differences between Monolith and Microservices application
- Learn about benefits and challenges with Microservices
- Learn about 12 factors app

## Chapter 14 - Case-study  - what will the case study be about? We should include in the title.


### 8.1 How to run pytest on RSVP application in `Jenkins Pipeline`?
### 8.2 How to build Docker image in `Jenkins Pipeline`?
### 8.3 How to push Docker image to Docker Hub in `Jenkins Pipeline`?
### 8.4 How to deploy RSVP application on `staging server` in `Jenkins Pipeline`?



## 8.1 Run Pytest on RSVP application in Jenkins Pipeline.

##### 1. Goto `Github` and fork `cloudyuga/rsvp` repository to your acoount. Ceate  file `run_test.sh` in forked repository as below.
```
#!/bin/bash
virtualenv rsvpapp --system-site-packages -v
source rsvpapp/bin/activate
pip install -r requirements.txt
pytest tests/test_rsvpapp.py
```
##### 2. Now goto you Jenkins Dashboard and create the new job named `TestRSVPCI` and choose `Pipeline` type job, Click on `OK`.
##### 3. Give Description about the job in `Descrption` section.
##### 4. Scroll down and goto the `Pipeline` section write down there script as below. Give the proper name of nodeas u have earlier set. 
```
stage('test'){
  node ('docker-jenkins-slave'){
  git 'https://github.com/vishalcloudyuga/rsvpapp.git'
  sh 'chmod a+x ./run_test.sh'
  sh './run_test.sh'
  }
}
```
##### 5. Click on the `Save` option and you will navigate to another window.
##### 6. Clck on the `build now` button. and your project building process will start.
##### 7. In Build History tab Click on the job and choose `Console Output`, here we can see our job build is succesfull or not , we can see successful result of pytest.

## 8.2 Build Docker Image in Jenkins Pipeline.
`Note: Make sure there is no slave node present except Master node, if there is any Slave node present make sure Docker is installed on that slave node`
##### 1. Goto `Manage Jenkin` tab and goto `Manage plugins`.
##### 2. Make sure you have installed the `Docker Pipeline` plugins.
##### 3. Lets configure Earlier created job `TestRSVPCI`.
##### 4. Scroll down and goto `Pipeline` section and modifie the Pipeline script. you can take help of Pipeline syntax while creating `build the image` in following scripts. 

##### 5. For getting  correct syntax of pipelins script for  `build the image` stage goto the `Pipeline sysntax` at left corner. You will move to Pipeline Syntax. Where you can find correct syntax for various operation that can be inserted in Pipeline script. Now in Pipeline syntax In `Sample step` select `withDockerServer: Sets Up Docker server endpoint`.

##### 6. Paste URL of `dockerhost` We have created in  earlier in `Yet another Docker` section and choose `dokerhost` credentials we have created earlier. and click on `Generate Pipeline Script` button. and copy that script and paste in your `build the image` stage of pipeline section. and modify code at `//some block` with `docker.build 'cloudyuga/rsvp'`. Give appropriae image name prefix with your Dockerhub username. Here cloudyuga is our dockerhub username.

![withDockerServer: Sets Up Docker server endpoint](images/jendockend.jpg)

##### 7. Make Pipeline script like with the appropriate changes in  IP address of dockerhost and image names.
```
stage('test'){
  node ('docker-jenkins-slave'){
  git 'https://github.com/vishalcloudyuga/rsvpapp.git'
  sh 'chmod a+x ./run_test.sh'
  sh './run_test.sh'
  }
}

node(){
stage('build the image'){
  withDockerServer([credentialsId: 'dockerhost', uri: 'tcp://104.131.28.112:2376']) {
    docker.build 'cloudyuga/rsvp'
}


}

```
##### 8.Click on the `Save` option and you will navigate to `TestRSVPCI` Job window.
##### 9. Clck on the `build now` button. and your project's building process will start. And it will give error as we have not installed docker on `jenkins` Droplet.
##### 10 Install the docker on the droplet where our `jenkin` is running. For docker installation please visit [here](https://github.com/cloudyuga/containers-for-all/blob/master/4-container_runtimes.md)
##### 11. Lets go back to the browser where the Jenkins is running and goto `TestRSVPCI` after that click on `build now`. Now we can see job finished successfully.


## 8.3 Dockerpush in Jenkins Pipeline.

##### 1. Goto `Manage Jenkins` and goto `Manage plugins`.
##### 2. Make sure you have installed the `Docker Pipeline` plugins.
##### 3. Goto `Jenkins Dashboard` > `Credentials` > `System` > `Global Credentials` > `Add Credentials` Choode `kind` as `Docker Registry Auth` 
##### 4. Now Add your `DockerHub` credentials like username,password etc and save that credentials.
##### 3. Lets configure Earlier created job `TestRSVPCI`.
##### 4. Scroll down and goto `Pipeline` section and modifie the Pipeline script. you can take help of Pipeline syntax while creating stage  `push the image to Dockerhub` in following script. 
##### 5. For correct syntax of  `push the image to DockerHub` stage. Click on `Pipeline sysntax` at left corner. You will move to Pipeline Syntax.  In `Sample step` select `withDockerregistry: Sets Up Docker registry endpoint`. choose the credentials `Docker Registry Auth` and click on `Generate Pipeline Script` button. and copy that script and paste in your `push the image to DockerHub` stage of pipeline section. and modify code at `//some block` with ` docker.image('cloudyuga/rsvp').push()` give the name of your image you have build in `buil the image` stage.

##### 6. Make Pipeline script like with the appropriate changes in  IP address of dockerhost and image names.
```
stage('test'){
  node ('docker-jenkins-slave'){
  git 'https://github.com/vishalcloudyuga/rsvpapp.git'
  sh 'chmod a+x ./run_test.sh'
  sh './run_test.sh'
  }
}

node(){
stage('build the image'){
  withDockerServer([credentialsId: 'dockerhost', uri: 'tcp://104.131.28.112:2376']) {
    docker.build 'cloudyuga/rsvp'
}
stage('push the imageto DockerHub'){
        withDockerServer([credentialsId: 'dockerhost', uri: 'tcp://104.131.28.112:2376']) {
            withDockerRegistry([credentialsId: 'dockerhub_auth']) {
            docker.image('cloudyuga/rsvp').push()
            }
        }        
 }
}
```
##### 7. Click on the `Save` option and you will navigate to `TestRSVPCI` Job window.
##### 8. Clck on the `build now` button. and your project's building process will start. 
##### 9. After succefull build. Log on to your `Docker Hub` and check your recently pushed image through jenkins pipeline will be present there.

## 8.4 Deploy `RSVP` application on `staging server` in Jenkins Pipeline

##### 1.Create a `Docker-Machine` with name `staging` on Digitalocean from `jenkins` droplet's terminal. Please refer the chapter no. 2 `Docker Essentials` of the course for details.
##### 2. Goto `Jenkins Dashboard` > `Credentials` > `System` > `Global Credentials` > `Add Credentials` Choode `kind` as `Docker Host Certification Authentication`
- You have navigated to `Jenkins Credential provider` window. In front of `Kind` click and choose the `Docker Host Certificate Authentication` 
- Go to the Terminal and Run `docker-machine env staging` and go the path where certificate resides.
- Execute `$ cat /root/.docker/machine/machines/staging/key.pem` and copy the key and paste it in `Client Key` in `Jenkins Credential provider` window.
- Execute `$ cat /root/.docker/machine/machines/staging/cert.pem` and copy the certificate and paste it in `Client Certificate` in `Jenkins Credential provider` window.
- Execute `$ cat /root/.docker/machine/machines/staging/ca.pem` and copy the certificate and paste it in `Server CA Certificate` in `Jenkins Credential provider` window.
- In `ID` section write down `staging-server`
- In Description section write `Staging Server`.

##### 3. Install the `Docker-Compose` on the `jenkins` droplet.
##### 4. Lets configure Earlier created job `TestRSVPCI`.
##### 5. Scroll down and goto `Pipeline` section and modifie the Pipeline script. you can take help of Pipeline syntax while creating stage  `deploy the image to staging server` in following way.
##### 6.  Click on `Pipeline sysntax` at left corner. You will move to Pipeline Syntax.  In `Sample step` select `withDockerServer: Sets Up Docker server endpoint`.
##### 7. Paste URL of `Staging Docker-machine` We have created recntly  and choose `staging-server` credentials. and click on `Generate Pipeline Script` button. and copy that script and paste in your `deploy the image to staging server` stage of pipeline script section. and later modifies code at `//some block`.
##### 8. final Pipeline-scripts will be look like. Make appropriate changes with your IP adress of `dockerhost`, `staging server` and the Name of images in following pipeline script.

```
stage('test'){
  node ('docker-jenkins-slave'){
  git 'https://github.com/vishalcloudyuga/rsvpapp.git'
  sh 'chmod a+x ./run_test.sh'
  sh './run_test.sh'
  }
}

node(){
stage('build the image'){
  withDockerServer([credentialsId: 'dockerhost', uri: 'tcp://104.131.28.112:2376']) {
    docker.build 'cloudyuga/rsvp'
}
stage('push the imageto DockerHub'){
        withDockerServer([credentialsId: 'dockerhost', uri: 'tcp://104.131.28.112:2376']) {
            withDockerRegistry([credentialsId: 'dockerhub_auth']) {
            docker.image('cloudyuga/rsvp').push()
            }
        }        
    }
 stage('deploy the image to staging server'){
        withDockerServer([credentialsId: 'staging-server', uri: 'tcp://138.197.118.55:2376']) {
        
            sh 'docker-compose -p rsvp_staging up -d'
            
        }
        
        input 'Check application running at http://138.197.118.55:5000'
        
        withDockerServer([credentialsId: 'staging-server', uri: 'tcp://138.197.118.55:2376']) {
        
            
            sh 'docker-compose -p rsvp_staging down -v'
        }
  
    }   
}
```
##### 9.Click on the `Save` option and you will navigate to another window.
##### 10. Clck on the `build now` button. and your project building process will start. 
##### 11. Check the `console output`, we can see more detailed output of job build.
##### 12. In Build History tab Click on the job and choose `Console Output`, here we can see our job build is succesfull or not , we can see successful result of pytest. And we can see RSVP application is running at the IP shown in console output and also we can see build is waiting for our choice  `Proceed` or `Abort` to complete the job. click on `Proceed` to complete the successful build. 






## What is continuous integration 

Continuous integration (CI) usually refers to integrating, building, and testing code within the development environment.

- Developers pushed the codes into the shared repository.

- Tests has to be performed on the commited code.

Here is the diagram which depict the flow :

![Continous Integration Flow](images/CI.png)

## What is continuous deployment/delivery

Continuous delivery is a software engineering approach in which teams produce software in short cycles, ensuring that the software can be reliably released at any time. It aims at building, testing, and releasing software faster and more frequently. The approach helps reduce the cost, time, and risk of delivering changes by allowing for more incremental updates to applications in production. A straightforward and repeatable deployment process is important for continuous delivery. 

Continuous Deployment is the deployment or release of code to Production as soon as it is ready.  There is no large batching in Staging nor long UAT process that is directly before Production.  Any testing is done prior to merging to the Mainline branch and is performed on Production-like environments.The Production branch is always stable and ready to be deployed by an automated process.  The automated process is key because it should be able to be performed by anyone in a matter of minutes (preferably by the press of a button).  After a deploy, logs must be inspected to determine if your key metrics are affected, positively or negatively.  Some of these metrics may include revenue, user sign-up, response time or traffic, preferably these metrics are graphed for easy consumption.  Continuous Deployment requires Continuous Integration and Continuous Delivery. 

![Continous Deployment Flow](images/cd_process_diagram-resized-600.png)

## How to deploy Jenkins in a container

Start jenkins with docker container
 
>$ docker run -it -p 8080:8080 jenkins

 - Copy the secret key
 
  ![enter image description here](https://lh3.googleusercontent.com/-rPXLn0VRO18/WAIUybFE1bI/AAAAAAAAAHc/JKVjU6ykLOkpv6R_DKjUqMp4rdfzyQbewCLcB/s0/snapshot56.png "snapshot56.png")
 
 - Start browser with link and Paste secret key in Administrator Password
http://localhost:8080
![enter image description here](https://lh3.googleusercontent.com/Hj2CD4MR1l-Rjxavzzsa7p4BhcDtbx_aLKvmxijZCEhZfWJJMKorYgc0_SoNsrW8n5HQonA=s0 "snapshot36.png")

 -  Paste initialAdminPassword previous in Administration Password in Time-line menu then Press Button continue in blue color button icon

## How to install a plugin in Jenkins 
 - Configure to select plugin given in option to install(Use Install suggested plugins if don't know or either than select plugins to install )
![enter image description here](https://lh3.googleusercontent.com/-Vi4_rGP-VcY/WAHzIfqPuZI/AAAAAAAAAC0/cnTjBUt3WXMohz5eGOyafs0qAr-gUs6qgCLcB/s0/snapshot37.png "snapshot37.png")

 - Wait for complete the Process
![enter image description here](https://lh3.googleusercontent.com/-YeDkNo7v7_Y/WAICzxoQ_QI/AAAAAAAAAE8/XSRwoBjxCAYbizba6vWMS253MZ9L_7j4gCLcB/s0/snapshot44.png "snapshot44.png")

 - Now create user and password 
 ![enter image description here](https://lh3.googleusercontent.com/-C8OsI2n7XZU/WAHzl0YbgGI/AAAAAAAAAC8/V6C1pG4NIj8-UFahN7zbjkNmygrluxooACLcB/s0/snapshot38.png "snapshot38.png")

 -  Start jenkins to make configure
![enter image description here](https://lh3.googleusercontent.com/-k7l_QMTmDNg/WAHz3a-LTGI/AAAAAAAAADI/GpblG-8jax0paSQO3hUPPJnzVoANsgyFACLcB/s0/snapshot39.png "snapshot39.png")

## How to configure a slave in Jenkins 
 - Click  link Create New job
![enter image description here](https://lh3.googleusercontent.com/-kxiAjc1ZKro/WAH_Etv8WPI/AAAAAAAAAEc/Qc5VrnMGd9wwNnYReNoj1VFw5ROJlDM8wCLcB/s0/snapshot40.png "snapshot40.png")

 - Type the name of project and press ok (use Freestyle Project ) 
![enter image description here](https://lh3.googleusercontent.com/-u7pxydktQBE/WAH0_wLhmLI/AAAAAAAAADo/2OTS0BpIkV43dir78EDWqi2R37-I_FsLgCLcB/s0/snapshot42.png "snapshot42.png")

Now Start the Project with test demo

 - Type the name of project is rsvpapp and press ok (use Freestyle Project ) 
![enter image description here](https://lh3.googleusercontent.com/-Zmgq4271vJY/WAIFCUFPhnI/AAAAAAAAAFU/Fl8s5imn4SwngKB9FmxUJxMRRP6HPP-ygCLcB/s0/snapshot47.png "snapshot47.png")

 Configure the project
 - Project name

 ![enter image description here](https://lh3.googleusercontent.com/-NbZfgzgTFFo/WAIIvvVMN1I/AAAAAAAAAFo/o9KQAcFzrqIRj2-0gwpeTJm_Vw5qa558QCLcB/s0/snapshot48.png "snapshot48.png")

 - Configure git path repository
![enter image description here](https://lh3.googleusercontent.com/-1-jBTpKk0GY/WAII1ywPGUI/AAAAAAAAAFw/bW6JDOLt5NczypVQfcIV4LnHZ9Pe91dcQCLcB/s0/snapshot49.png "snapshot49.png")

 - Set Poll SCM 
![enter image description here](https://lh3.googleusercontent.com/-7bMQvgyB1zk/WAII8YUgQUI/AAAAAAAAAF4/p_3BgAewHc4fMU46OAOJEujEMbrDxyTUwCLcB/s0/snapshot50.png "snapshot50.png")

 - Enter the Command line for build in Execute Shell
![enter image description here](https://lh3.googleusercontent.com/-foc-EAJMBCY/WAIJHyfcpZI/AAAAAAAAAGA/cgCCf5vmAtkPzfxmGKVj0lyYWPyD44MxwCLcB/s0/snapshot51.png "snapshot51.png")

## How to trigger a build on a slave 
 - Press the Build Now Button left side in timeline menu
 ![enter image description here](https://lh3.googleusercontent.com/-eZWoxtEnako/WARgQAVr2nI/AAAAAAAAAIM/OnQJzaAWUykMDmxyeU55NXHrACHr1ejLwCLcB/s0/snapshot63.png "snapshot63.png")v
 - Now start the build process
![enter image description here](https://lh3.googleusercontent.com/-n5mA0rQ2h8I/WAIJNYaKjwI/AAAAAAAAAGI/Fbwj8d4fNTYHWymvwD1rZPwPiD9UM2L4wCLcB/s0/snapshot52.png "snapshot52.png")

 - check build log go to the console output
 ![enter image description here](https://lh3.googleusercontent.com/-8WQIRK6iLcI/WARgBXDul4I/AAAAAAAAAIE/fg8JIpHdkhYipM1BqlBAl1dMrxDswb5IACLcB/s0/snapshot64.png "snapshot64.png")
 
 - View the log
 ![enter image description here](https://lh3.googleusercontent.com/-ZfguFE6GDt0/WARhcNdEvmI/AAAAAAAAAIY/fFR_tOe9a7sYRVe4dnbiKIUaA-Z3ZtK5ACLcB/s0/snapshot66.png "snapshot66.png")
 ![enter image description here](https://lh3.googleusercontent.com/Du4nfo1egp7YQHSevfexZFLO8V7diLQj1wTmPtstZJvo_Gd_ggx5VzM4WyodA9PBb3LJIj6l=s0 "snapshot65.png")

## How to configure Docker Plugin for Jenkins 
 - Goto the home the press the Manage Jenkins left side on the timeline menu
 ![enter image description here](https://lh3.googleusercontent.com/-LHJ9-krNDXA/WARiAqjQJxI/AAAAAAAAAIw/qlqWIN8V6cQC5BFQsDcMVdf4og0avcg6gCLcB/s0/snapshot67.png "snapshot67.png")
 - Press the link of manage plugin 
 ![enter image description here](https://lh3.googleusercontent.com/-1vrDN9JjhwY/WARj-HwuxTI/AAAAAAAAAJc/e_cW6A6_fTAtuWbsHQNVIV5xuGyTYClawCLcB/s0/snapshot69.png "snapshot69.png")
 - Go to the Available menu and type menu searching name docker
 ![enter image description here](https://lh3.googleusercontent.com/-BcknF_pWQ3w/WARk_79CZuI/AAAAAAAAAJw/OitG4xcxMTAhZpkZNr8KaRjENmpaA8ISwCLcB/s0/snapshot70.png "snapshot70.png")
 
 - Then drag the menu check in click check box of Docker plugin and press the install button below the line
 ![enter image description here](https://lh3.googleusercontent.com/-hCDLnsc4CIk/WARmEQyaiEI/AAAAAAAAAKE/SffLfgFAlLcLnl04RlOcTNWHtUobs0IKACLcB/s0/snapshot71.png "snapshot71.png")
 
 - wait for process to complete
 ![enter image description here](https://lh3.googleusercontent.com/-2QgiB6m2B3I/WARozIxgHJI/AAAAAAAAAKo/waw5UcmDSbMEm9dPlohgfO_ZuRV9Mw2tQCLcB/s0/snapshot73.png "snapshot73.png") 

 - Go to the Jenkins configuration or Configure Systems link is  http://localhost:8080/configure
 ![enter image description here](https://lh3.googleusercontent.com/AF6-32JZKzzHarGsoPNJZUJVw4q5Ns1nkhSppfcggBeeuGfNoZAIZqGYoM6CLXmlSXz08BSm=s0 "snapshot69.png")
 - Drag the menu click to Add New Cloud and Fill the text and Press Test Connection for work or not then save the configuration 
![enter image description here](https://lh3.googleusercontent.com/-m_7oE_yjpKY/WARx10BFJHI/AAAAAAAAALY/EHYErlvAAlo-vXatCOuCsxVVicpdaAfsACLcB/s0/snapshot77.png "snapshot77.png")

## How to use trigger a build on a container using Docker Plugin 
 -  Now back to the Jenkins manage http://localhost:8080/manage drag the menu check the icon of docker press  link button
 ![enter image description here](https://lh3.googleusercontent.com/-7JQWgWIbYBc/WARzVuAGNaI/AAAAAAAAALk/gMg5LyzeRoEW4oL-WIGVbDY4id3O10SpQCLcB/s0/snapshot78.png "snapshot78.png")
 
 - list of docker Server and the press link of Docker
 ![enter image description here](https://lh3.googleusercontent.com/-Choo5esrdJ8/WARzmucicLI/AAAAAAAAALs/_BvJK0gJDzwkX2wVqzU18KgIZ4djGWEDwCLcB/s0/snapshot79.png "snapshot79.png")

 - check the docker working container and images
![enter image description here](https://lh3.googleusercontent.com/-1q6T3hZ93ZE/WAR0OrsyShI/AAAAAAAAAL4/xgdxUtUYSRACNlngA0cQe5VERB5snRC2ACLcB/s0/snapshot80.png "snapshot80.png")

## How to configure Docker Slave Plugin for Jenkins
 
 - Goto the home the press the Manage Jenkins left side on the timeline menu
 ![enter image description here](https://lh3.googleusercontent.com/-LHJ9-krNDXA/WARiAqjQJxI/AAAAAAAAAIw/qlqWIN8V6cQC5BFQsDcMVdf4og0avcg6gCLcB/s0/snapshot67.png "snapshot67.png")
 
 - Press the link of manage plugin 
 ![enter image description here](https://lh3.googleusercontent.com/-1vrDN9JjhwY/WARj-HwuxTI/AAAAAAAAAJc/e_cW6A6_fTAtuWbsHQNVIV5xuGyTYClawCLcB/s0/snapshot69.png "snapshot69.png")

 - Then drag the menu check in click check box of Docker Slave plugin and press the install button below the line
 ![enter image description here](https://lh3.googleusercontent.com/-5WHGIvUBzSI/WASOR5pNxNI/AAAAAAAAAMo/3HINdNr7n0QAv1eSIXUmcUQmKEQ0uZfQwCLcB/s0/snapshot81.png "snapshot81.png")
 

 - Wait to complete the Process
 ![enter image description here](https://lh3.googleusercontent.com/-6ELoTMDulFU/WASO-OUqP3I/AAAAAAAAAM0/nJFQyzzN2jwHRBBJyuT1WtaUuBrstJhfACLcB/s0/snapshot82.png "snapshot82.png")

 - Go to the Jenkins configuration or Configure Systems link is  http://localhost:8080/configure
 ![enter image description here](https://lh3.googleusercontent.com/AF6-32JZKzzHarGsoPNJZUJVw4q5Ns1nkhSppfcggBeeuGfNoZAIZqGYoM6CLXmlSXz08BSm=s0 "snapshot69.png")
  

 - Drag the menu  and check Docker slave and Fill the text and Press Test Connection for work or not then save the configuration
![enter image description here](https://lh3.googleusercontent.com/-duWbMEfn7fo/WASRNbvUoFI/AAAAAAAAANI/1kdoyomfKnomvH4BHtZwZQrOCwDoklItgCLcB/s0/snapshot83.png "snapshot83.png")

 - go to home press rsvpapp  project to configure http://localhost:8080/job/rsvpapp/configure
 ![enter image description here](https://lh3.googleusercontent.com/-nWAJE82nKpw/WASSxJ7_biI/AAAAAAAAANU/1OjMnf06C387JyGPR1iV4ldg0lfEgJCRwCLcB/s0/snapshot84.png "snapshot84.png") 

 - Start the build process
 ![enter image description here](https://lh3.googleusercontent.com/-4d7VFIddw9A/WAST7CF3upI/AAAAAAAAANs/CHgR2lZAqtkQXJJekwl9UH2YemVtgzYVwCLcB/s0/snapshot86.png "snapshot86.png")
![enter image description here](https://lh3.googleusercontent.com/-38F33GJGps4/WASbZYVui0I/AAAAAAAAAOM/YkEgpbK3xZ0p8e9agQBuEutaTgVuvYMsQCLcB/s0/snapshot88.png "snapshot88.png")

 - check project log
 ![enter image description here](https://lh3.googleusercontent.com/-PQqK1NV03Fg/WASb71PqqNI/AAAAAAAAAOU/EM1ErM2-4SgDtUDjdfiC_UsTlPgbSX9IQCLcB/s0/snapshot89.png "snapshot89.png")
![enter image description here](https://lh3.googleusercontent.com/-BRSBaCL1nxM/WAScAdySI5I/AAAAAAAAAOc/j3hNYZBApbAMoVmXbIuF5i9M5o-5oXV0QCLcB/s0/snapshot90.png "snapshot90.png")
![enter image description here](https://lh3.googleusercontent.com/-CG66Jv3tbDc/WAScErgrYcI/AAAAAAAAAOk/PjHaphW9yvoZHRSM3_G9OgWDoL2DxgYFACLcB/s0/snapshot91.png "snapshot91.png")

## What is Jenkins pipeline feature 

## How to use Jenkins pipepine to set Dev and QA pipeline 
 - Type the name of project is rsvpapp and press ok (use Jenkins pipeline ) 
 ![enter image description here](https://lh3.googleusercontent.com/-1Sw0YIXBvZ0/WAWsbI9esCI/AAAAAAAAAQM/89QeE_nbh0E_qAiTxoMM-T5XCcD-psBPgCLcB/s0/snapshot96.png "snapshot96.png")
 
 - Project name
 ![enter image description here](https://lh3.googleusercontent.com/-035B1VH5kuM/WAWtgYj8mcI/AAAAAAAAAQY/-uyA9sbDEm071xfb53tRLD6Zvft_534RgCLcB/s0/snapshot97.png "snapshot97.png")
 
 - Set Poll SCM 
 ![enter image description here](https://lh3.googleusercontent.com/-vTWtEFTEmH0/WAWuYj4y64I/AAAAAAAAAQo/c4Asg06dHo8rAxoFQr1ZAMe9dwhXChKUgCLcB/s0/snapshot98.png "snapshot98.png")

 - First go to the pipeline syntax its seen below big text box and press link to go for pipeline syntax,  its very helpful to create pipeline script made easy.
 ![enter image description here](https://lh3.googleusercontent.com/-B17BMtRuJxc/WAWvF7FfanI/AAAAAAAAAQ0/-DOpv18oQxIYxCHfJYXjYqa-VDBzyLO7QCLcB/s0/snapshot99.png "snapshot99.png")
 

 - Pipeline syntax.
 ![enter image description here](https://lh3.googleusercontent.com/-usJgU1XYHQg/WAWv1oWO3BI/AAAAAAAAARI/ye8V6Nc0F0Ys0XAahvItcalqgsmaTo9LwCLcB/s0/snapshot100.png "snapshot100.png")

 - First step  in Sample step Drag and Select in sh: Shell Script,   type command in shell script text box  and press Generate Groovy 
 and copy the output.
 ![enter image description here](https://lh3.googleusercontent.com/-x7-ydKwhIvw/WAW1EcYAPAI/AAAAAAAAARw/-r7RpUzlpWgd1N6eaYW2z2cydyQdnFJkgCLcB/s0/snapshot101.png "snapshot101.png")

 - Paste in the pipeline Script.
 ![enter image description here](https://lh3.googleusercontent.com/-OJn_qnCJnwE/WAW2MRYFn4I/AAAAAAAAAR8/vWrIYvcpMWwzqnGBKnpX4HGLagTG9unigCLcB/s0/snapshot102.png "snapshot102.png")
 

 - Second Step again go to pipeline syntax in Sample step Drag and Select in git,   type git location in text box  and press Generate Groovy  and copy the output.
 ![enter image description here](https://lh3.googleusercontent.com/-724RpOXlszw/WAW3MviXGpI/AAAAAAAAASI/YjTEV3OtxlY1yUhQSGux4D1pMrvcfWXHACLcB/s0/snapshot103.png "snapshot103.png")
 
 - Paste in the pipe line script.
 ![enter image description here](https://lh3.googleusercontent.com/-erzgZcjmM4U/WAW3lyyYdRI/AAAAAAAAASY/f9GKCzG77nI6Q5pXGg9pS82lr8MIEhWkACLcB/s0/snapshot104.png "snapshot104.png")

 - Third step again go to pipeline syntax  in Sample step Drag and Select in dir:Change Current Directory,   type command in Path text box " . " (dot) and press Generate Groovy  and copy the output.
 ![enter image description here](https://lh3.googleusercontent.com/-JAeYfEQgluE/WAW6HfBNk0I/AAAAAAAAAS0/7At5AeVIazUq5c5Z6ay_MBFKPzlgzzhCgCLcB/s0/snapshot105.png "snapshot105.png")
 
 - Paste in the pipeline Script
 ![enter image description here](https://lh3.googleusercontent.com/-Jc2aVcYQFPI/WAW7DPpP8CI/AAAAAAAAAS8/riZ6bpj0nocnPhlqKZy8UJ8BX-36IUTEwCLcB/s0/snapshot107.png "snapshot107.png")

 - Fourth step again go to pipeline syntax  in Sample step Drag and Select in node:Allocate Node and press Generate Groovy  and copy the output.
![enter image description here](https://lh3.googleusercontent.com/-aVZLZdKlTKA/WAW7HezsONI/AAAAAAAAATI/HwaBaBXYq6ctkFd-qgQCM2zQL84u2wPzwCLcB/s0/snapshot106.png "snapshot106.png")

 - Paste in the pipeline Script. and press the save Button
 ![enter image description here](https://lh3.googleusercontent.com/-nZp02z5TE04/WAW76EDpIXI/AAAAAAAAATc/7nAazXJl1KAjY3rk_DcYP2KQNIs-BJDbwCLcB/s0/snapshot108.png "snapshot108.png")
 
 - Press Build Now on left side menu
 ![enter image description here](https://lh3.googleusercontent.com/-sH7tLlQQJTs/WAW8a8-V94I/AAAAAAAAATs/JdD_dTfp1Xkzg_VDcbdVlCS4GqpVom7ogCLcB/s0/snapshot109.png "snapshot109.png")

 - Wait for Complete the Process
 ![enter image description here](https://lh3.googleusercontent.com/-9kgwh1g7nso/WAW87cpzSKI/AAAAAAAAAT8/lWgQg5VRdnI9Y3wZYL4NHF5F9BkjyGXaACLcB/s0/snapshot110.png "snapshot110.png")

 - Go to the console Output log
 ![enter image description here](https://lh3.googleusercontent.com/-9Lz3jslHyAQ/WAW9syHDvBI/AAAAAAAAAUM/t6YJrTD77_YvrOcdwjFB-2e_wOpep5ISgCLcB/s0/snapshot111.png "snapshot111.png")

 - View log
 ![enter image description here](https://lh3.googleusercontent.com/--TYzIdiXcek/WAW-O03FKLI/AAAAAAAAAUc/bSu-e-3NYeI-qbYShcqYsQSpZUtMmg_3gCLcB/s0/snapshot112.png "snapshot112.png")
![enter image description here](https://lh3.googleusercontent.com/RxGKFIc0vypfl3xnSpCPnE-6aMQVDxhofb8ihRUDROaPHvRUqKi6IRXQc-vhvsZn8loYabJ1=s0 "snapshot113.png")
![enter image description here](https://lh3.googleusercontent.com/BX1HEL3WLBdFY3ydadrTyYxbPIwO48vYyV2iGGWDb9nKJxQzy45G1A_kFaWEFuXBvB60TNt5=s0 "snapshot114.png")
 - Setup simple staging Enter command text
 ![enter image description here](https://lh3.googleusercontent.com/-2Ilr8Zy-7U8/WAXYP8q7XNI/AAAAAAAAAV8/BkOlzSEa2aARJpYZv7sZjmxjckksaGq8QCLcB/s0/snapshot115.png "snapshot115.png")

 - Press Build Now
 ![enter image description here](https://lh3.googleusercontent.com/-8wFLIgknmSo/WAXYpFn0-iI/AAAAAAAAAWE/RPyrcXWMdgg_N_O1kWTGyIUwaci97WvbQCLcB/s0/snapshot116.png "snapshot116.png")
 - View like
![enter image description here](https://lh3.googleusercontent.com/-5tXzQEXcoJQ/WAXY7YhpmzI/AAAAAAAAAWM/Gwj3Je1KERsQwZXbHKg-wi9ZMWQSd2woQCLcB/s0/snapshot117.png "snapshot117.png")

 - Check stage log Started
 ![enter image description here](https://lh3.googleusercontent.com/-vU2OowPWYHs/WAXbdI2IIlI/AAAAAAAAAXI/Snq7Vu8Ytxstk2npsvBVv-bC7LZ6mmNBwCLcB/s0/snapshot122.png "snapshot122.png")
 - View log
 ![enter image description here](https://lh3.googleusercontent.com/-Jy7GYZPaNBc/WAXbkzgqleI/AAAAAAAAAXQ/0UCUsMEebZcDWGiRnq9aWqAHtDm1JIUcgCLcB/s0/snapshot121.png "snapshot121.png")
 -  Check stage log  packaging and Compiling_test
 ![enter image description here](https://lh3.googleusercontent.com/-mSdtOKUE_nU/WAXaU281vFI/AAAAAAAAAWo/ONsHsx7oyQM4R2NwNSlyWBat7TzsCKyqgCLcB/s0/snapshot118.png "snapshot118.png")
 
 - View log
 ![enter image description here](https://lh3.googleusercontent.com/-sA1I1eno0Ks/WAXag8yI8JI/AAAAAAAAAWw/OvnqPWTdUT09NqSeoump7_kslvVTMOVNQCLcB/s0/snapshot119.png "snapshot119.png")
 ![enter image description here](https://lh3.googleusercontent.com/-JERSUhrioxs/WAXakgR-7OI/AAAAAAAAAW4/kxfigvvIlzkD70wBpdrxcXG4qNQZ6_V7gCLcB/s0/snapshot120.png "snapshot120.png")




### 5.1 How to download and install vscode?
### 5.1 How to install plugings in the vscode?
### 5.2 How to build Docker images from vscode?
### 5.2 How to use `docker-compose` command is vsode?

## 5.1 vscode setup. 
##### 1. Go to https://code.visualstudio.com/download and download the vscode installer for windows/linux/mac and install it. After installation Launch the vscode. 
##### 2. When vscode is launched press `ctrl + p` and in command line insert `> shell` and choose `Shell Command: Install 'code' command in PATH` and hit `enter` button.
##### 3. Now go to your `rsvpapp` directory through `command terminal` and execute following command.
```
$ code .
```
this directory will automatically open in vscode editor.

##### 4. Install plugins in vscode
After lauching the vscode at the leftside on `activity bar` you will find the `extensions` icon. Click on it and install following extensions.
`python`, `Docker Support`, `Docker Linter` and `Git easy`. After successfull installation of plugins click on the `Reload` and vscode will get reload. Now open the `rsvpapp` folder from the File tab of vscode. In Left pannel you may see yours files and directories of the `rsvpapp`. 
 
 ##### 5. Make sure have set environment variables to use Docker plugins.
 Before proceeding further make sure that you have given the path of Dockerhost in environment variable. if not then please refer the `Chapter no. 3` of this course.
 
 Now if you have set `dockerhost` path in environment variable then please restart the vscode. After opening the vscode and `rsvpapp` folder through it. You may see following like window.
 
 ![vscode on windows](images/vscode1.jpg)
## 5.2 Docker operation in vscode

##### 1. Docker Image build using the vscode.
Make sure that you have installed the docker plugins. `Docker Support`, `Docker Linter` these plugins must be present in your vscode.
In the left panel we can see the directories and files inside the `rsvpapp` directory. Now right click on the `Dockerfile` and choose option `Docker: Build Image`. And give the name to image and press enter your image. 

![vscode Docker Image Build](images/vscode2.jpg)

##### 2. Docker-Compose up using vscode
Press `ctrl + p` and type `>Docker:Compose` and choose the `Docker:Compose Up` from suggested commands and press enter key. now choose `docker-compose.yml` and press enter key. In the terminal of vscode we can see our apllication is being deployed. We can check in browser by entering the ip adrress at 5000 port of dockerhost. Our `RSVP app` application has been deployed using docker compose in vscode.

![vscode Docker-compose](images/vscode3.jpg)
##### 3. Docker-Compose Down using the vscode
You can simply kill `RSVP app`, Press `ctrl + p` and type `>Docker:Compose` and choose the `Docker:Compose Down` from suggested commands and press enter key. now choose `docker-compose.yml` and press enter key. In the terminal of vscode we can see our apllication is being stopped and containers used with it are being removed. 

##### If you want to secure your Docker Daemon with TLS then please refer [Protect the Docker daemon socket](https://docs.docker.com/engine/security/https/)

## References. 
#### 1. https://code.visualstudio.com/
#### 2. https://docs.docker.com/engine/security/https/


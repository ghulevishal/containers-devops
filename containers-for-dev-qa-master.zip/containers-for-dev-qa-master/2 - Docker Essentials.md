
### Prerequisites for lab
Docker must be installed on your system.
## 2.1 Docker Architecture
Docker has a client-server archtecture, in which client sends the commands to Dockerhost that runs Docker Daemon. Client and Dockerhost can be either on same the machine or on different machines. Dockerhost pulls and push images to and from Docker registry.
###### Figure 2.1:Docker Architecture
![Docker Architecture](images/docker2.1.jpg)

Docker client and Docker Daemon communicates over rest API. Docker client can be configured to coonect multiple Docker Daemon running on dfferent systems.

## 2.2 Docker Machine
[Docker Machine](https://docs.docker.com/machine/overview/) is a tool with which we can install Docker Engine on virtual hosts and then we can manage them. With this tool, we can create Docker hosts on our local Linux/Mac/Windows box, on cloud providers like AWS or Digital Ocean, etc.
###### Figure 2.2:Docker Machine
![Docker Machine](images/dockermachine22.jpg)

###  How to use docker-machine to create a Docker instance on DigitalOcean and connect to it ?

#### Setup Docker Machine on the workstation

#### Linux
On the the workstation earlier and download the binary.
 ```
$ curl -L https://github.com/docker/machine/releases/download/v0.8.2/docker-machine-`uname -s`-`uname -m` >/usr/local/bin/docker-machine && \
chmod +x /usr/local/bin/docker-machine
 ```
#### Mac
If you have installed `Docker for Mac` or `Docker toolbox` then `docker-machine` binary is automatically installed with it. To check the version, run following command :-

```
$ docker-machine version
docker-machine version 0.9.0, build 15fd4c7
```

#### Windows
If you have installed `Docker for Windows` or `Docker toolbox` then `docker-machine` binary is automatically installed with it.  

#### Get the access token from your DigitalOcean account to authenticate automatically. 
Follow the [DigitalOcean tutorial](https://www.digitalocean.com/community/tutorials/how-to-use-the-digitalocean-api-v2) to generate the access token.

  ```
$ export DO_TOKEN='14c91a0f332370bc89d9.......'
  ``` 

1. Create a Docker host on DigitalOcean using `docker-machine`, where `demo` would be our Docker Host name. 

 ```
$ docker-machine create --driver digitalocean --digitalocean-access-token=$DO_TOKEN dockerhost
Creating CA: /root/.docker/machine/certs/ca.pem
Creating client certificate: /root/.docker/machine/certs/cert.pem
Running pre-create checks...
Creating machine...
(dockerhost) Creating SSH key...
(dockerhost) Creating Digital Ocean droplet...
(dockerhost) Waiting for IP address to be assigned to the Droplet...
Waiting for machine to be running, this may take a few minutes...
Detecting operating system of created instance...
Waiting for SSH to be available...
Detecting the provisioner...
Provisioning with ubuntu(systemd)...
Installing Docker...
Copying certs to the local machine directory...
Copying certs to the remote machine...
Setting Docker configuration on the remote daemon...
Checking connection to Docker...
Docker is up and running!
To see how to connect your Docker Client to the Docker Engine running on this virtual machine, run: docker-machine env dockerhost
 ```

	With the `driver` option, we provide the provider on which we will create the VM and install Docker. `virtualbox`, `aws`, `digitalocean`, etc., are supported drivers. 
	

2. How to connect to the newly created Docker host from Docker client ?

	List the configuration variables for newly created host.

 ```
$ docker-machine env dockerhost
export DOCKER_TLS_VERIFY="1"
export DOCKER_HOST="tcp://159.203.134.28:2376"
export DOCKER_CERT_PATH="/root/.docker/machine/machines/dockerhost"
export DOCKER_MACHINE_NAME="dockerhost"
# Run this command to configure your shell:
# eval $(docker-machine env dockerhost)
 ```

3. Export the configuration variables as environment variables, so docker client can connect to it.

 ```
$ eval $(docker-machine env dockerhost)
 ```

	From now on, whatever command we will run, it would run on VM referred by the `dockerhost` instance, as it sets the `DOCKER_HOST` variable.  Setting up Docker host via `docker-machine`  also sets the TLS certificates to enable a secure communication between the client and the host. The creation of `docker-machine` downloads the client certificates locally from the Docker host under  `/root/.docker/machine/machines/`. *DOCKER_TLS_VERIFY="1"* forces the secure communication between the docker client and the host. 


4. How to list all the instances managed by `docker-machine` ?

 ```
$ docker-machine ls
NAME         ACTIVE   DRIVER         STATE     URL                         SWARM   DOCKER    ERRORS
dockerhost   *        digitalocean   Running   tcp://159.203.134.28:2376           v1.13.1
 ```
 
	We can manage more than one host via `docker-machine`. A star sign in the `Active` column refers to the host for which Docker client is configured now. 

5. Run the container on `docker-machine`.

 ```
$ docker container run -d nginx:alpine
Unable to find image 'nginx:alpine' locally
alpine: Pulling from library/nginx
b7f33cc0b48e: Pull complete
9a57e9207914: Pull complete
79f62f9c7236: Pull complete
50a2334db9bc: Pull complete
Digest: sha256:d34e2176dab830485b0cb79340e1d5ebf7d530b34ad7bfe05d269ffed20a88f
Status: Downloaded newer image for nginx:alpine
d4b90e455c94fd7cd8e500d4168b231d897fb58959c22830560cab9b32586762
 ```
 
6. List the containers.

 ```
$ docker container ls
CONTAINER ID        IMAGE               COMMAND                  CREATED              STATUS              PORTS               NAMES
d4b90e455c94        nginx:alpine        "nginx -g 'daemon ..."   About a minute ago   Up About a minute   80/tcp, 443/tcp     peaceful_euclid
 ```

7. Take SSH accees of the `docker-machine` to verify the running containers. Also check that docker daemon at docker-machine is configured with TLS.

 ```
$ docker-machine ssh dockerhost
Welcome to Ubuntu 16.04.1 LTS (GNU/Linux 4.4.0-62-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  Get cloud support with Ubuntu Advantage Cloud Guest:
    http://www.ubuntu.com/business/services/cloud

5 packages can be updated.
2 updates are security updates.

*** System restart required ***
$ root@dockerhost:~# docker container ls
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS               NAMES
d4b90e455c94        nginx:alpine        "nginx -g 'daemon ..."   52 minutes ago      Up 52 minutes       80/tcp, 443/tcp     peaceful_euclid

$ root@dockerhost:~# ps aux | grep dockerd
root     16778  0.2  8.9 453832 44612 ?        Ssl  07:00   0:07 dockerd -H tcp://0.0.0.0:2376 -H unix:///var/run/docker.sock --storage-driver aufs --tlsverify
root     17348  0.0  0.1  12944   944 pts/0    S+   08:02   0:00 grep --color=auto dockerd

$ root@vishal:~# exit
logout
Connection to 104.131.85.254 closed.
 ```

8. How to delete the `dockerhost` instance, we created earlier ?

 ```
$ docker-machine rm dockerhost
About to remove dockerhost
Are you sure? (y/n): y
Successfully removed dockerhost
 ```

## 2.3 Docker Container Operations

1. Check whether Docker-machine created via Docker Toolbox is running or not? If it is not present then please create Docker-machine as explained above.

 ```
$ docker-machine ls
NAME         ACTIVE   DRIVER         STATE     URL                         SWARM   DOCKER    ERRORS
dockerhost   *        digitalocean   Running   tcp://104.131.87.115:2376           v1.13.1
 ```

2. How to run containers?

 ```
$ docker container run -i -t alpine sh
Unable to find image 'alpine:latest' locally
latest: Pulling from library/alpine
0a8490d0dfd3: Pull complete
Digest: sha256:dfbd4a3a8ebca874ebd2474f044a0b33600d4523d03b0df76e5c5986cb02d7e8
Status: Downloaded newer image for alpine:latest
/ # ps aux
PID   USER     TIME   COMMAND
    1 root       0:00 sh
    5 root       0:00 ps aux
/ # 
 ```
 
3. List the containers.

 ```
$ docker container ls
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES
c80fe6e7e878        alpine              "sh"                5 minutes ago       Up 5 minutes                            loving_poincare
 ```
4. Start the container with name and make it in background.

 ```
$ docker container run -d --name=web nginx:alpine
Unable to find image 'nginx:alpine' locally
alpine: Pulling from library/nginx
b7f33cc0b48e: Pull complete
9a57e9207914: Pull complete
79f62f9c7236: Pull complete
50a2334db9bc: Pull complete
Digest: sha256:d34e2176dab830485b0cb79340e1d5ebf7d530b34ad7bfe05d269ffed20a88f4
Status: Downloaded newer image for nginx:alpine
99a966317351e5473782f6209cc9634cc25fcceda3e109681531d1d075c4253b
 ```
 
5. List the running container

 ```
$ docker container ls
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS               NAMES
99a966317351        nginx:alpine        "nginx -g 'daemon ..."   28 seconds ago      Up 27 seconds       80/tcp, 443/tcp     web
c80fe6e7e878        alpine              "sh"                     16 minutes ago      Up 16 minutes                           loving_poincare
 ```
 
6. Access the container `web`

 ```
$ docker container inspect web | less

$ docker container exec -it web sh
/ # ps aux
PID   USER     TIME   COMMAND
    1 root       0:00 nginx: master process nginx -g daemon off;
    5 nginx      0:00 nginx: worker process
    6 root       0:00 sh
   10 root       0:00 ps aix
/ #
 ```

7. Stop the running container

 ```
$ docker container stop web
web
 ```
8. Remove the container

 ```
$ docker container rm web
web
 ```

9. Remove running container forcefully.
 ```
$ docker container ls
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES
c80fe6e7e878        alpine              "sh"                32 minutes ago      Up 32 minutes                           loving_poincare

$ docker rm -f c80fe6e7e878
c80fe6e7e878
 ```

## 2.4 Docker Image operations

1. Check whether Docker-machine created is running or not?

 ```
$ docker-machine ls
NAME         ACTIVE   DRIVER         STATE     URL                         SWARM   DOCKER    ERRORS
dockerhost   *        digitalocean   Running   tcp://104.131.87.115:2376           v1.13.1
 ```
2. List all the locally present images

 ```
$ docker image ls
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               alpine              c24ab147adf9        2 weeks ago         54.3 MB
alpine              latest              88e169ea8f46        6 weeks ago         3.98 MB
 ```
4. Pull images from repository.

 ```
$ docker image pull busybox
Using default tag: latest
latest: Pulling from library/busybox
4b0bc1c4050b: Pull complete
Digest: sha256:817a12c32a39bbe394944ba49de563e085f1d3c5266eb8e9723256bc4448680e
Status: Downloaded newer image for busybox:latest

$ docker image ls
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               alpine              c24ab147adf9        2 weeks ago         54.3 MB
busybox             latest              7968321274dc        3 weeks ago         1.11 MB
alpine              latest              88e169ea8f46        6 weeks ago         3.98 MB

 ```
5. Tag image and remove the images from dockerhost.
 ```
$ docker image tag busybox neependra/busybox:test

$ docker image ls
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               alpine              c24ab147adf9        2 weeks ago         54.3 MB
busybox             latest              7968321274dc        3 weeks ago         1.11 MB
neependra/busybox   test                7968321274dc        3 weeks ago         1.11 MB
alpine              latest              88e169ea8f46        6 weeks ago         3.98 MB

$ docker image rmi alpine
Untagged: alpine:latest
Untagged: alpine@sha256:dfbd4a3a8ebca874ebd2474f044a0b33600d4523d03b0df76e5c5986cb02d7e8
Deleted: sha256:88e169ea8f46ff0d0df784b1b254a15ecfaf045aee1856dca1ec242fdd231ddd
Deleted: sha256:60ab55d3379d47c1ba6b6225d59d10e1f52096ee9d5c816e42c635ccc57a5a2b
 ```
 
## 2.5 Dockerfiles

Docker can build image automatically by reading the instructions from the Dockerfile. Dockerfile is the text file which contains various intructions required for building the images.

1. Check the connectivity to the Docker host.

 ```
$ docker-machine ls
NAME         ACTIVE   DRIVER         STATE     URL                         SWARM   DOCKER    ERRORS
dockerhost   *        digitalocean   Running   tcp://104.131.87.115:2376           v1.13.1
 ```
2. Create the directory first.

 ```
$ mkdir -p nginx

$ cd nginx
$ vim Dockerfile
 ```
3. Create the Dockerfile as shown below.
 ```
FROM debian:jessie

MAINTAINER NGINX Docker Maintainers "docker-maint@nginx.com"

ENV NGINX_VERSION 1.11.9-1~jessie

RUN apt-key adv --keyserver hkp://pgp.mit.edu:80 --recv-keys 573BFD6B3D8FBC641079A6ABABF5BD827BD9BF62 \
	&& echo "deb http://nginx.org/packages/mainline/debian/ jessie nginx" >> /etc/apt/sources.list \
	&& apt-get update \
	&& apt-get install --no-install-recommends --no-install-suggests -y \
						ca-certificates \
						nginx=${NGINX_VERSION} \
						nginx-module-xslt \
						nginx-module-geoip \
						nginx-module-image-filter \
						nginx-module-perl \
						nginx-module-njs \
						gettext-base \
	&& rm -rf /var/lib/apt/lists/*

# forward request and error logs to docker log collector
RUN ln -sf /dev/stdout /var/log/nginx/access.log \
	&& ln -sf /dev/stderr /var/log/nginx/error.log

EXPOSE 80 443

CMD ["nginx", "-g", "daemon off;"]

 ```
4. Build the image from Dockerfile

 ```
$ docker build -t neependra/nginx .
Sending build context to Docker daemon  2.56 kB
Step 1/7 : FROM debian:jessie
 ---> e5599115b6a6
.
.
.
.
.
.

Removing intermediate container 6f6e0327af9a
Step 6/7 : EXPOSE 80 443
 ---> Running in 78fb305920e5
 ---> 5ec06cef1889
Removing intermediate container 78fb305920e5
Step 7/7 : CMD nginx -g daemon off;
 ---> Running in 846854dcedf1
 ---> 1a0c1f82ae05
Removing intermediate container 846854dcedf1
Successfully built 1a0c1f82ae05
 ```
	Note: `docker build -t.... .` command must be executed within directory which contains Dockerfile.
5. Run the container from recently created image `neependra/nginx`.
 ```
$ docker container run -d neependra/nginx:latest
 ```

6. List the running containers.

 ```
$ docker container ls
CONTAINER ID        IMAGE                    COMMAND                  CREATED              STATUS              PORTS               NAMES
518fceeebc74        neependra/nginx:latest   "nginx -g 'daemon ..."   About a minute ago   Up About a minute   80/tcp, 443/tcp     unruffled_spence
 ```
 
7. For more detailed practice on Dockerfile please refer to the [Dockerfile References](https://docs.docker.com/engine/reference/builder/)

## 2.6.1 Docker Image Push

1. Create the account at Docker Hub.

2. login to docker hub via terminal as below

 ```
$ docker login

Login with your Docker ID to push and pull images from Docker Hub. If you don't have a Docker ID, head over to https://hub.docker.com to create one.
Username: cloudyuga
Password:
Login Succeeded
 ```

3. Verify the Docker login and username.
 ```
$ docker info | less
.
.
.
.
.
.
Kernel Version: 4.4.0-62-generic
Operating System: Ubuntu 16.04.1 LTS
OSType: linux
Architecture: x86_64
CPUs: 1
Total Memory: 488.4 MiB
Name: dockerhost
ID: BR6U:M6EN:VCM7:56MM:EOXY:J6OK:75KD:7SNA:OQJI:KFCA:Z35U:2DPE
Docker Root Dir: /var/lib/docker
Debug Mode (client): false
Debug Mode (server): false
Username: cloudyuga
Registry: https://index.docker.io/v1/
WARNING: No swap limit support
Experimental: false
Insecure Registries:
 127.0.0.0/8
Live Restore Enabled: false
(END)
 ```

4. To push the image we must to take care that name of image must be prefix with the username we have logged in.
 ```
$ docker image ls
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               latest              cc1b61406712        2 weeks ago         182 MB
busybox             latest              7968321274dc        4 weeks ago         1.11 MB
alpine              latest              88e169ea8f46        6 weeks ago         3.98 MB
 ```
	Here we want to push alpine:latest image so we have to tag that image with our username.
 ```
$ docker image tag alpine cloudyuga/alpine:mooc

$ docker image ls
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               latest              cc1b61406712        2 weeks ago         182 MB
busybox             latest              7968321274dc        4 weeks ago         1.11 MB
alpine              latest              88e169ea8f46        6 weeks ago         3.98 MB
cloudyuga/alpine    mooc                88e169ea8f46        6 weeks ago         3.98 MB
 ```
 
5. Push image to Docker Hub.
 ```
$ docker image push cloudyuga/alpine:mooc
The push refers to a repository [docker.io/cloudyuga/alpine]
60ab55d3379d: Mounted from library/alpine
mooc: digest: sha256:dfbd4a3a8ebca874ebd2474f044a0b33600d4523d03b0df76e5c5986cb02d7e8 size: 528
 ```

6. Login to the Docker Hub account and you can see the recently pushed image.

## 2.6.2 Docker Automated build.
If you have source code repository at `Github`. From which we build our application in `Docker Image` and ship it to our customers. There is mechanism in which whenever we update source code at given repository on `Github` then respected image will be created on the `Docker Hub`.  Docker Hub has functionality called `Docker Automated Builds` by which we can trigger build on Docker hub as soon as we commit source code on `Github` repository. 

1. Login to DockerHub.

2. Click on `Create` > `Create Automated Build` > `Link Account` link your Github account.

3. Once your Github account is linked then again click on `Create` > `Create Automated Build` > `Create Auto-Build Github` > select the repository which you want to link. Then click on create.

4. Lets go to our `Github` repository and make changes there. As soon as we commit the change  `Docker Automated Build` process will start on our Docker Hub account.


## 2.7 Docker Volumes 

1. Create a new volume of name `myvol`.
 ```
$ docker volume create myvol
myvol
 ```

2. List the available Volumes.
 ```
$ docker volume list
DRIVER              VOLUME NAME
local               myvol
 ```

3. Mount a volume inside a container.
 ```
$ docker container run -it -v myvol:/data alpine sh
Unable to find image 'alpine:latest' locally
latest: Pulling from library/alpine
0a8490d0dfd3: Pull complete
Digest: sha256:dfbd4a3a8ebca874ebd2474f044a0b33600d4523d03b0df76e5c5986cb02d7e8
Status: Downloaded newer image for alpine:latest
/ # cd /data/
/data # touch f1 f2
/data # exit
 ```

4. Create a new container from busybox image but mount same volume `myvol`. And `/data/` we can see the files we have created earlier.
 ```
$ docker container run -it -v myvol:/data busybox sh
/ # ls /data/
f1  f2
/ # exit
 ```

5. Now lets check inside the Docker-machine. And check `myvol` and it's contents. 
 ```
$ docker-machine ssh dockerhost
Welcome to Ubuntu 16.04.1 LTS (GNU/Linux 4.4.0-62-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

  Get cloud support with Ubuntu Advantage Cloud Guest:
    http://www.ubuntu.com/business/services/cloud

10 packages can be updated.
2 updates are security updates.

*** System restart required ***

$ root@dockerhost:~# cd /var/lib/docker/volumes/

$ root@dockerhost:/var/lib/docker/volumes# ls
metadata.db  myvol

$ root@dockerhost:/var/lib/docker/volumes# cd myvol/

$ root@dockerhost:/var/lib/docker/volumes/myvol# ls
_data

$ root@dockerhost:/var/lib/docker/volumes/myvol# cd _data/

$ root@dockerhost:/var/lib/docker/volumes/myvol/_data# ls
f1  f2
 ```
 
## 2.8 Docker Networking

1. Check the connectivity to the Docker host.

 ```
$ docker-machine ls
NAME         ACTIVE   DRIVER         STATE     URL                         SWARM   DOCKER    ERRORS
dockerhost   *        digitalocean   Running   tcp://104.131.87.115:2376           v1.13.1
 ```

2. To demonstrate Docker networking lets first create a container from `nginx` image.
 ```
$ docker container run -d nginx:alpine
9614dd9e9831f26d292490faecb372781b984057d7323c7dec1fad4a94ed2e2b
 ```

3. Lets check the running container list and port exposed to ths container.
 ```
$ docker container ls
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS               NAMES
9614dd9e9831        nginx:alpine        "nginx -g 'daemon ..."   3 minutes ago       Up 3 minutes        80/tcp, 443/tcp     pensive_yonath
 ```

3. Lets get containers IP adsress using following command.
 ```
$ docker container inspect 9614dd9e9831
.
.
.
.
 "bridge": {
     "IPAMConfig": null,
     "Links": null,
     "Aliases": null,
     "NetworkID": "7abeba79bf0ae5f0049e9c875a5ee942ce21b03e9758772ffe8e5694498cc4d2",
     "EndpointID": "b8cb27086f858e4ac7b431d8b2c28fd99129c1d0f4630cf5477d52786fb65c25",
     "Gateway": "172.17.0.1",
     "IPAddress": "172.17.0.3",
     "IPPrefixLen": 16,
     "IPv6Gateway": "",
     "GlobalIPv6Address": "",
     "GlobalIPv6PrefixLen": 0,
     "MacAddress": "02:42:ac:11:00:03"
.
.
.
.
 ```

4. But this IP address is given by docker0 bridge and this is not accessible from outside of world. So for making container accessible from outside world we have do container port mapping between host port and container port.

 ```
$ docker container run -d -p 8080:80 nginx:alpine
50f87a8eb9b5793a947f9f44a0964b7a54443ca7712c7409fa372227ec31b779

$ docker-machine ls
NAME         ACTIVE   DRIVER         STATE     URL                         SWARM   DOCKER    ERRORS
dockerhost   *        digitalocean   Running   tcp://104.131.87.115:2376           v1.13.1
 ```
	We can access the container by IP address of Host and port ampped to container. It means above containe is accesible at `104.131.87.115:8080`.

5. We can map random port to the container.
 ```
$ docker container run -d -P nginx:alpine
d5df4ba792fc6f5c3057b7964a7a8971439262e1dd08b179dafdf1faf65d044e
 ```

6. We can check the random port assigned to the container we recently launched.
 ```
$ docker container ls
root@vishal:~# docker container ls
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                                           NAMES
03400f216b15        nginx:alpine        "nginx -g 'daemon ..."   21 seconds ago      Up 20 seconds       0.0.0.0:32769->80/tcp, 0.0.0.0:32768->443/tcp   quirky_shockley
50f87a8eb9b5        nginx:alpine        "nginx -g 'daemon ..."   5 minutes ago       Up 5 minutes        443/tcp, 0.0.0.0:8080->80/tcp                   fervent_euler
9614dd9e9831        nginx:alpine        "nginx -g 'daemon ..."   18 minutes ago      Up 18 minutes       80/tcp, 443/tcp                                 pensive_yonath
 ```

we can see the the port `32769`is assigned to the container that means container is accessible at `32769` port of host. Container is accessible at `104.131.87.115:32769`

## 2.9 Docker Compose
Docker-compose is the tool with which we can create multi-container application within a on command. If you are using `Docker Toolbox` then Docker compose is by default installed on your system. Or more help regarrding the installation of Docker-compose you can refer this [Docker-compose](https://docs.docker.com/compose/install/)

1. Create directory called `wordpress`
 ```
$ mkdir wordpress
$ cd wordpress
 ```

2. create `docker-compose.yaml` as below.
 ```
version: '2'

services:
   db:
     image: mysql:5.7
     volumes:
       - db_data:/var/lib/mysql
     restart: always
     environment:
       MYSQL_ROOT_PASSWORD: wordpress
       MYSQL_DATABASE: wordpress
       MYSQL_USER: wordpress
       MYSQL_PASSWORD: wordpress

   wordpress:
     depends_on:
       - db
     image: wordpress:latest
     ports:
       - "8000:80"
     restart: always
     environment:
       WORDPRESS_DB_HOST: db:3306
       WORDPRESS_DB_PASSWORD: wordpress
volumes:
    db_data:
 ```

3. Run the application using `docker-compose up -d` command
 ```
$ docker-compose --tlsverify --tlscacert /root/.docker/machine/machines/dockerhost/ca.pem --tlscert=/root/.docker/machine/machines/dockerhost/cert.pem --tlskey=/root/.docker/machine/machines/dockerhost/key.pem -H tcp://104.131.87.115:2376 up -d
 ```

4. List the containers created by  `docker-compose`
 ```
$ docker-compose --tlsverify --tlscacert /root/.docker/machine/machines/dockerhost/ca.pem --tlscert=/root/.docker/machine/machines/dockerhost/cert.pem --tlskey=/root/.docker/machine/machines/dockerhost/key.pem -H tcp://104.131.87.115:2376 ps

        Name                       Command               State          Ports
-------------------------------------------------------------------------------------
wordpress_db_1          docker-entrypoint.sh mysqld      Up      3306/tcp
wordpress_wordpress_1   docker-entrypoint.sh apach ...   Up      0.0.0.0:8000->80/tcp
 ```

5. Stop the application
 ```
$ docker-compose down -v
 ```








## Windows
## Docker Machine and Docker Compose using Window Toolbox

### Docker Machine on windows.
 
  
1. Choose Start > Task Manager and navigate to the Performance tab. Under CPU Make sure that virtualization is enabled.
  
2. Go to https://www.docker.com/products/docker-toolbox and download the Docker Toolbox installer for windows.
  
3. Install the Docker Toolbox.

4. Open the Desktop of computer and open the application called `Docker Quickstart Terminal` It will check pre-create and   download latest Boot2Docker and create Default Docker Machine.

5. Once Defult Docker machine is created ypu can check `docker run hello-world`. You can see whether your Docker-Machine is correctly running or not.
  
6. on the terminal execute folloeing command to create Docker-Machine on Digital Ocean. Give Ditial oceans Token and create machine there on Docker Quickstart Terminal. 
 ```
  $ export DO_TOKEN='14c91a0f332370bc89d9.......'
      
  $ docker-machine create --driver digitalocean --digitalocean-access-token=$DO_TOKEN demo
  
  $ docker-machine ls
  
  $ docker-machine env demo
  
  $ eval $("C:\Program Files\Docker Toolbox\docker-machine.exe" env demo)
  
  $ docker run -d nginx:alpine
  
  $ docker-machine ssh demo
  
  $ ps aux
  
  $ exit
  
  $ docker-machine rm demo
  
 ```
 
### Docker-Compose on windows
As we have already installed the Docker Toolbox it containes `Docker-compose` in build within it. We just have to carry out following comands whiledemonstrating use of docker compose with the windows. Just create all `dcker-compose.yml` in `wordpress` direcory as menntioned above.

1. $ eval $("C:\Program Files\Docker Toolbox\docker-machine.exe" env default)

2. $ docker-machine ls

3. $ mkdir ~/wordpress

4. $ cd ~/wordpress

5. $ vim docker-compose.yml

6. $ docker-compose up -d

7. Check application running on the ip address of the `docker-machine`.

8. $ docker-compose down

## References
- https://docs.docker.com
- https://docs.docker.com/engine/security/https/
- https://docs.docker.com/machine/overview/


### 4.1 What is Docker Compose?
### 4.1 How to Deploy RSVP application using Docker-Compose?
### 4.1 How to use docker compose with TLS secured Docker-Machine?
### 4.1 How to set environment variables of Docker-machine?
### 4.1 How to stop application and it's running containers using Docker Compose?
##  Docker Compose 
[Docker Compose](https://docs.docker.com/compose/overview/) is a tool by which we can create a multi-container application. We define a multi-container application in a YAML file like following:-

```
version: '2'
services:
  web:
    build: .
    ports:
    - "5000:5000"
    volumes:
    - .:/code
    - logvolume01:/var/log
    links:
    - redis
  redis:
    image: redis
volumes:
  logvolume01: {}
```

In the YAML file, `version` field defines the version format of the Docker Compose file. In the *services* section we define different containers with their configuration. We can define *volumes*, *networks* and other details in the compose file. You can find the complete reference for the Compose file [here](https://docs.docker.com/compose/compose-file/)

In the example shown above from the [Docker documentation](https://docs.docker.com/compose/overview/) we are creating an application from two containers `web` and *redis*. `web` container would be build from the Dockerfile located in the current folder. And *redis* container from *redis* image. We would also create a volume  *logvolume01* on the host and mount it inside the *web* container. *web* container would also mount current folder under */code*.  And we are mapping *5000* port of the host system with *5000* port of *web* container. 
 
### Prerequisites for lab.
- The `docker-compose` must be installed on your droplet.
- The `docker machine` must be created at digital ocean. If docker machine is not present then Please refer chapter no. 2 `Essential` and create docker machine with name `dockerhost`

## 4.1 Install Docker Compose

##### 1.Download Docker Compose ?

Download Docker Compose from the Docker GitHub.
```
$ curl -L "https://github.com/docker/compose/releases/download/1.9.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose


  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100   600    0   600    0     0    373      0 --:--:--  0:00:01 --:--:--   373
100 7857k  100 7857k    0     0   337k      0  0:00:23  0:00:23 --:--:-- 1232k
```

##### 2. Set the executbale permission. 
```
$ chmod +x /usr/local/bin/docker-compose 
```
## 4.2 Deploy RSVP with Docker Compose 

##### 1. If `rsvpapp` directory is not present aon your system then lets clone the github repository of the `RSVP app`

```
$ git clone https://github.com/cloudyuga/rsvpapp.git
$ cd rsvpapp/

```
##### 2. Let's take a look at the Docker-Compose file  `docker-compose.yml`

```
version: '2'
services:
 mongodb:
   image: mongo:3.3   
   expose:                 
     - "27017"
   environment:    
    MONGODB_DATABASE: rsvpdata
   networks:
    - rsvpnet

 web:
   image: cloudyuga/rsvp:app
   ports:
    - "5000:5000"
   environment:
    MONGODB_HOST: mongodb
    LINK: http://www.meetup.com/cloudyuga/
    TEXT1: CloudYuga 
    TEXT2: Garage RSVP!
    LOGO: https://raw.githubusercontent.com/cloudyuga/rsvpapp/master/static/cloudyuga.png
    COMPANY: CloudYuga Technology Pvt. Ltd.
   networks:
    - rsvpnet

networks:
  rsvpnet:

```
##### 3. Deploy the RSVP application on TLS verified Docker machine `dockerhost` using the `docker-compose up -d`. Please refer to the chapter no.2 `Essentials` for more help regarding TLS Docker compose and Docker machines.
```
$ docker-compose --tlsverify --tlscacert /root/.docker/machine/machines/dockerhost/ca.pem --tlscert=/root/.docker/machine/machines/dockerhost/cert.pem --tlskey=/root/.docker/machine/machines/dockerhost/key.pem -H tcp://104.131.87.115:2376 up -d

Creating network "rsvpapp_rsvpnet" with the default driver
Creating volume "rsvpapp_db_data" with default driver
Pulling mongodb (mongo:3.3)...
3.3: Pulling from library/mongo
386a066cd84a: Pull complete
524267bc200a: Pull complete
476d61c7c43a: Pull complete
0750d0e28b90: Pull complete
c2a78c5fad8e: Pull complete
14474a0ebc1b: Pull complete
0b42389b77aa: Pull complete
de77b4fcbe14: Pull complete
975aabf0feac: Pull complete
Digest: sha256:08a90c3d7c40aca81f234f0b2aaeed0254054b1c6705087b10da1c1901d07b5d
Status: Downloaded newer image for mongo:3.3
Pulling web (teamcloudyuga/rsvpapp:mooc)...
mooc: Pulling from teamcloudyuga/rsvpapp
c0cb142e4345: Pull complete
bc4d09b6c77b: Pull complete
606abda6711f: Pull complete
809f49334738: Pull complete
2ddb8c93131d: Pull complete
0af27d7f0701: Pull complete
Digest: sha256:fcc6d802388a3027e9461876c2a5bfaa51dc0e7c10664be7be9cd76db2b4f03a
Status: Downloaded newer image for teamcloudyuga/rsvpapp:mooc
Creating rsvpapp_mongodb_1
Creating rsvpapp_web_1
```
You can see the RSVP application is running at the 5000 port in IP address of the Docker-machine `dockerhost`.
For eg. At my system it s running on `104.131.87.115:5000`.

##### 4. Lets list the running containers used by `docker compose` for RSVP application.
```
$ docker-compose --tlsverify --tlscacert /root/.docker/machine/machines/dockerhost/ca.pem --tlscert=/root/.docker/machine/machines/dockerhost/cert.pem --tlskey=/root/.docker/machine/machines/dockerhost/key.pem -H tcp://104.131.87.115:2376 ps

      Name                   Command            State           Ports
------------------------------------------------------------------------------
rsvpapp_mongodb_1   /entrypoint.sh mongod       Up      27017/tcp
rsvpapp_web_1       /bin/sh -c python rsvp.py   Up      0.0.0.0:5000->5000/tcp
```
##### 5. Stop the running RSVP application.
```
$ docker-compose --tlsverify --tlscacert /root/.docker/machine/machines/dockerhost/ca.pem --tlscert=/root/.docker/machine/machines/dockerhost/cert.pem --tlskey=/root/.docker/machine/machines/dockerhost/key.pem -H tcp://104.131.87.115:2376 stop

Stopping rsvpapp_web_1 ... done
Stopping rsvpapp_mongodb_1 ... done
```

##### 6. Remove the container used by the `docker-compose` and RSVP application.
```
$ docker-compose --tlsverify --tlscacert /root/.docker/machine/machines/dockerhost/ca.pem --tlscert=/root/.docker/machine/machines/dockerhost/cert.pem --tlskey=/root/.docker/machine/machines/dockerhost/key.pem -H tcp://104.131.87.115:2376 rm

Going to remove rsvpapp_web_1, rsvpapp_mongodb_1
Are you sure? [yN] y
Removing rsvpapp_web_1 ... done
Removing rsvpapp_mongodb_1 ... done
```
#### If you want to store the TLS certificate path in your bash terminal then follow the step 7 For `Linux`. Step 8 for `Mac os` and step 9 for `Windows`
### On Linux.
##### 7. We add the environment variable of `dockerhost` to the `.bashrc` follow the commands.
- Check the environment variables of the `dockerhost`.
```
$ docker-machine env dockerhost
export DOCKER_TLS_VERIFY="1"
export DOCKER_HOST="tcp://159.203.134.28:2376"
export DOCKER_CERT_PATH="/root/.docker/machine/machines/dockerhost"
export DOCKER_MACHINE_NAME="dockerhost"
# Run this command to configure your shell:
# eval $(docker-machine env dockerhost)
```
- Copy the environment varibles of `dockerhost`.
- in termnal open the and open file `.bashrc` by running the following command.
```
$ vim ~/.bashrc
```
In `.bashrc` file scroll down and copy the `dockerhost` environment varibles. Save it and close the file.

- Log out and log in to terminal or execute following command.
```
$ source ~/.bashrc
```
- simply run the `docker-compose up -d` and our application will be deployed at the 5000 port of `dockerhost` IP address.
```
$ docker-compose up -d

Creating rsvpapp_mongodb_1
Creating rsvpapp_web_1
```
Go to browser and check at `dockerhost` ip address with 5000 port RSVP application is running.
- Stop RSVP application and remove the containers.
```
$ docker-compose down -v

Removing rsvpapp_mongodb_1 ... done
Removing rsvpapp_web_1 ... done
Removing network rsvpapp_rsvpnet
Removing volume rsvpapp_db_data

```

### Mac OS

##### 8. We add the environment variable of `dockerhost` to the `.zshrc` follow the commands.
- Check the environment variables of the `dockerhost`.
```
$ docker-machine env dockerhost
export DOCKER_TLS_VERIFY="1"
export DOCKER_HOST="tcp://159.203.134.28:2376"
export DOCKER_CERT_PATH="/root/.docker/machine/machines/dockerhost"
export DOCKER_MACHINE_NAME="dockerhost"
# Run this command to configure your shell:
# eval $(docker-machine env dockerhost)
```
- Copy the environment varibles of `dockerhost`.
- in termnal open the and open file `.zshrc` by running the following command.
```
$ vim ~/.zshrc
```
In `.zshrc` file scroll down and copy the `dockerhost` environment varibles. Save it and close the file.

- Log out and log in to terminal or execute following command.
```
$ source ~/.zshrc
```
- simply run the `docker-compose up -d` and our application will be deployed at the 5000 port of `dockerhost` IP address.
```
$ docker-compose up -d

Creating rsvpapp_mongodb_1
Creating rsvpapp_web_1
```
Go to browser and check at `dockerhost` ip address with 5000 port RSVP application is running.
- Stop RSVP application and remove the containers.
```
$ docker-compose down -v

Removing rsvpapp_mongodb_1 ... done
Removing rsvpapp_web_1 ... done
Removing network rsvpapp_rsvpnet
Removing volume rsvpapp_db_data

```

### Windows Docker Toolbox
##### 9. Follow the following instructions.
- Check out present Docker-Machine. Enter in `Docker Quickstart termnal`
```
$ docker-machine ls

NAME         ACTIVE   DRIVER         STATE     URL                         SWARM   DOCKER    ERRORS
default      *        virtualbox     Running   tcp://192.168.99.100:2376           v1.13.0
dockerhost   -        digitalocean   Running   tcp://138.197.87.112:2376           v1.13.0

$ docker-machine env dockerhost

export DOCKER_TLS_VERIFY="1"
export DOCKER_HOST="tcp://138.197.87.112:2376"
export DOCKER_CERT_PATH="C:\Users\VISHAL\.docker\machine\machines\dockerhost"
export DOCKER_MACHINE_NAME="dockerhost"
# Run this command to configure your shell:
# eval $("C:\Program Files\Docker Toolbox\docker-machine.exe" env dockerhost)
```
- Add environment variables in windows.
As we are using windows and docker tool box so we have to set above environment of Docker-machine in Enviroment variables of windows.
###### 1. Goto `Control panel` and open `System and Security` then navigate to `System`.
![system and security](images/env1.jpg)

###### 2. You can see the `Advanced system setting ` click on that. And you navigate to another window, Select the `Environment Variables`
![Advanced system setting](images/env2.jpg)

###### 3. Now you can see `Environment Variables` window. Click on `New` under user variables and Add the Variable name and variable values
![Environment Variables](images/env3.jpg)
- variable name = DOCKER_TLS_VERIFY &  variable value = 1
- variable name = DOCKER_HOST & variable value = tcp://138.197.87.112:2376
- variable name = DOCKER_CERT_PATH & variable value = C:\Users\VISHAL\.docker\machine\machines\dockerhost
###### 4. Click on Ok.

- Now just go to CMD terminal. and enter into the `rsvpapp` directory.
```
C:\Users\VISHAL\rsvpapp>docker-compose up -d
Creating network "rsvpapp_rsvpnet" with the default driver
Creating rsvpapp_mongodb_1
Creating rsvpapp_web_1
```
Open the web browser and goto your IP address of your `DOCKERHOST` given in enviroment variable. Application is runnimg on `5000` port of that IP address for me it is running on  `138.197.87.112:5000`

- Lets stop application and remove the containers from windows CMD terminal.

```
C:\Users\VISHAL\rsvpapp>docker-compose down -v
Stopping rsvpapp_web_1 ...
Stopping rsvpapp_mongodb_1 ...
←[2BRemoving rsvpapp_web_1 ... done
Removing rsvpapp_mongodb_1 ...
←[2BRemoving network rsvpapp_rsvpnet
Removing volume rsvpapp_db_data
```


## References
#### 1. https://github.com/cloudyuga/containers-for-all/blob/master/12-docker_compose.md
#### 2. https://docs.docker.com/compose/overview/


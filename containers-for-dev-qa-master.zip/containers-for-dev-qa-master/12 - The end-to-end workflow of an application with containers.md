### 11.1 How to do passwordless SSH login?
### 11.2 How to set automatic job buld trigger in `Jenkins` for change in `Git Hub Repository` ?
### 11.3 How to deploy RSVP application using the `Docker stack` in jenkins pipeline?
### 11.4 How to change RSVP application from `vscode` and run application with reflected changes in `Jenkins`? 
## 11.1 Setting up production
## 12.1 Create passwordless ssh login to `manager`.
1. At your systems terminal or in `gitbash`. Create your ssh key.

  ```
  $ ssh-keygen -t rsa
  Generating public/private rsa key pair.
  Enter file in which to save the key (/c/Users/VISHAL/.ssh/id_rsa):
  Enter passphrase (empty for no passphrase):
  Enter same passphrase again:
  Your identification has been saved in /c/Users/VISHAL/.ssh/id_rsa.
  Your public key has been saved in /c/Users/VISHAL/.ssh/id_rsa.pub.
  The key fingerprint is:
  SHA256:Z51wnT46nJX6ViJPObA5x4fMt/o3Xx30b+En1NxSdKE VISHAL@VISHU
  The key's randomart image is:
  +---[RSA 2048]----+
  |               .+|
  |             ..o.|
  |          . .Eo..|
  |           +.o.=o|
  |        S o oBB==|
  |         o .=*%oO|
  |            **.BB|
  |             oo=+|
  |             o+.=|
  +----[SHA256]-----+
  ```
2. Create `.ssh` directory on the `manager` node. Use ssh to create a directory on manager.
  
  ```
  $ ssh root@104.131.185.248 mkdir -p .ssh
  ```
  
3. Copy our key `id_rsa.pub` on manager using terminal.

  ```
  $ cat ~/.ssh/id_rsa.pub | ssh root@104.131.185.248 'cat >> .ssh/authorized_keys'
 root@104.131.185.248's password:
  ```
4. Now you can ssh login to `manager` without password.

## 12.2 Create `Docker Machine` on `manager` from your systems terminal.

1. Create A `Docker Machine` of name `production`.

 ```
$ docker-machine create --driver generic --generic-ip-address=104.131.185.248 production
Running pre-create checks...
Creating machine...
(production) No SSH key specified. Assuming an existing key at the default location.
Waiting for machine to be running, this may take a few minutes...
Detecting operating system of created instance...
Waiting for SSH to be available...
Detecting the provisioner...
Provisioning with ubuntu(systemd)...
Installing Docker...
Copying certs to the local machine directory...
Copying certs to the remote machine...
Setting Docker configuration on the remote daemon...
Checking connection to Docker...
Docker is up and running!
To see how to connect your Docker Client to the Docker Engine running on this virtual machine, run: C:\Program Files\Docker Toolbox\docker-machine.exe env production
 ```
2. Lets check the environment of Docker-Machine

 ```
$ docker-machine env production
export DOCKER_TLS_VERIFY="1"
export DOCKER_HOST="tcp://104.131.185.248:2376"
export DOCKER_CERT_PATH="C:\Users\VISHAL\.docker\machine\machines\production"
export DOCKER_MACHINE_NAME="production"
export COMPOSE_CONVERT_WINDOWS_PATHS="true"
# Run this command to configure your shell:
# eval $("C:\Program Files\Docker Toolbox\docker-machine.exe" env production)
 ```
 
3. Make this Docker-Machine Active by running 
 ```
eval $("C:\Program Files\Docker Toolbox\docker-machine.exe" env production)
 ```
4. Now run `$ docker info | less` and it will the details of docker running on Docker-machine and also give info about the swarm node as shown below.
 ```
...
Swarm: active
 NodeID: 27fwsmvgwhtrh72c6fmpr8w6f
 Is Manager: true
 ClusterID: trq9rk8ffgfxpcgf98c5k211i
 Managers: 1
 Nodes: 2
 ...

 ```
 
5. Git clone the the `docker-stack.yaml`
 ```
$ wget https://raw.githubusercontent.com/nkhare/rsvpapp/master/docker-stack.yaml
 ```
 
6. Deploy the application using `Docker Stack`.
 ```
$ docker stack deploy -c docker-stack.yaml myrsvpapp
Ignoring deprecated options:

expose: Exposing ports is unnecessary - services on the same network can access each other's containers on any port.

Creating network myrsvpapp_rsvpnet
Creating service myrsvpapp_mongodb
Creating service myrsvpapp_web
 ```

7. Goto the browser and enter the IP address of `loadbalancer` droplet. and we can see our RSVP app is deployed.

8. Check the Docker Volumes.
 ```
$  docker volume ls
DRIVER              VOLUME NAME
local               myrsvpapp_db_data
 ```
9. Remove the Deployed application using following command.
 ```
$ docker stack rm myrsvpapp
Removing service myrsvpapp_web
Removing service myrsvpapp_mongodb
Removing service myrsvpapp_visualizer
Removing network myrsvpapp_default
Removing network myrsvpapp_rsvpnet
 ```

10. Remove the Docker volume.
 ```
$ docker volume rm myrsvpapp_db_data
myrsvpapp_db_data
 ```
 
## 11.3 Setting Up automatic job trigger in Jenkins.

1. Goto Jenkins in browser. And create new job `RSVPEndToEnd` scroll down and in copy from section enter `TestRSVPCI` we have earlier created. Click on `OK`.

2. You will navigate to configuration window there you can update desciprtion. Click on `Gitub project` and enter your forked `RSVP` repository adrress like `https://github.com/nkhare/rsvpapp.git` 

3. IN `Build Trigger` click on `Poll SCM` and enter `* * * * *`

4. Click on `save` and save job.

5. Goto your github RSVPrepository which you have provided in `RSVPEndToEnd` Job above and Create new file and commit it.

6. Go back to your Jenkins window in browser and you will see there new build has been started.

7. If you commit any change at your Git hub repository it triggers build job at Jenkins.

8. You can see RSVP app is running in web browser on staging server's IP.

## 11.4 Deploy app on `production` Docker machine using Jenkins.
1. Goto Terminal from where we have created the `production` docker machine and Execute.
 ```
$ docker-machine ls
NAME         ACTIVE   DRIVER    STATE     URL                          SWARM   DOCKER    ERRORS
production   *        generic   Running   tcp://104.131.185.248:2376           v1.13.0

$ docker-machine env production
export DOCKER_TLS_VERIFY="1"
export DOCKER_HOST="tcp://104.131.185.248:2376"
export DOCKER_CERT_PATH="/root/.docker/machine/machines/production/"
export DOCKER_MACHINE_NAME="production"
export COMPOSE_CONVERT_WINDOWS_PATHS="true"
# Run this command to configure your shell:
 ```
2. Goto `Jenkins Dashboard` > `Credentials` > `System` > `Global Credentials` > `Add Credentials` Choode kind as `Docker Host Certification Authentication`.
  
 -   You have navigated to `Jenkins Credential provider` window. In front of `Kind` click and choose the `Docker Host Certificate Authentication` 

 -   Go to the Terminal and Run `docker-machine env production` and go the path where certificate resides.
 -   Execute `$ cat /root/.docker/machine/machines/production/key.pem` and copy the key and paste it in `Client Key` in `Jenkins Credential provider` window.
 -   Execute `$ cat /root/.docker/machine/machines/production/cert.pem` and copy the certificate and paste it in `Client Certificate` in `Jenkins Credential provider` window.
 -   Execute `$ cat /root/.docker/machine/machines/production/ca.pem` and copy the certificate and paste it in `Server CA Certificate` in `Jenkins Credential provider` window.
 -   In `ID` section write down `production`
 -   In Description section write `Productioon Swarm cluster `.-

3. Open `RSVPEndToEnd` job we have recently created. And Lets configure it.

4. In PipeLine section Modifies pipeline script as below. add stage `
 ```
stage('test'){
  node ('docker-jenkins-slave'){
  git 'https://github.com/vishalcloudyuga/rsvpapp.git'
  sh 'chmod a+x ./run_test.sh'
  sh './run_test.sh'
  }
}

node(){
stage('build the image'){
  withDockerServer([credentialsId: 'dockerhost', uri: 'tcp://104.131.28.112:2376']) {
    docker.build 'cloudyuga/rsvp'
}
stage('push the image to DockerHub'){
        withDockerServer([credentialsId: 'dockerhost', uri: 'tcp://104.131.28.112:2376']) {
            withDockerRegistry([credentialsId: 'dockerhub_auth']) {
            docker.image('cloudyuga/rsvp').push()
            }
        }        
    }
 stage('deploy the image to staging server'){
        withDockerServer([credentialsId: 'staging-server', uri: 'tcp://138.197.118.55:2376']) {

            sh 'docker-compose -p rsvp_staging up -d'

        }

        input 'Check application running at http://138.197.118.55:5000'

        withDockerServer([credentialsId: 'staging-server', uri: 'tcp://138.197.118.55:2376']) {


            sh 'docker-compose -p rsvp_staging down -v'
        }

    }   
     stage('deploy in production'){
     withDockerServer([credentialsId: 'production', uri: 'tcp://104.131.185.248:2376']) {

            sh 'docker stack deploy -c docker-stack.yaml myrsvpapp'

        }
     input 'Check application running at http://104.131.185.248:5000'
     withDockerServer([credentialsId: 'production', uri: 'tcp://104.131.185.248:2376']) {

            sh 'docker stack down myrsvpapp'

        }
     
     }
}
 ```

5. Click on `save` and build the job. Use `Conole output` and you can see the application is deployed using the `Docker Stack` in `deploy in production` stage. Goto browser and check the application is running on `manager` and `workers` IP address. When click on proceed in  `Conole output` of jenkins build your application at `production` will shut down soon.

## 11.4 Ide to Deploy

1. Make sure you have installed `vscode` on your system.

2. Clone the `rsvpapp` directory from the `Git`.

3. Open that `rsvpapp` directory in the `vscode`.

4. Make change Goto `rsvpapp` > `templates` > `profile.html` and make change at 20th line Replace `Name` with `Your Name` and at 24th line replace `Email` by `Your Email` and save it.

5. Goto `docker-compose.yml` and `docker-stack.yaml` and change name of images with the name you have build images  in `build image`stage of jenkins `RSVPEndToEnd` job.

6. Save the files and then coomit and Push them to your `rsvpapp` GitHub repository with help of `Git easy` extension in `vscode`.

7. As soon as push your changes to the your `github` rsvpapp repository it trigger the build in jenkins. and you can see the job build is going on in jenkins tab. After successful job build you can see the changes you have made in vscode are reflected in the application running on the `manager` and  `worker` IP address.

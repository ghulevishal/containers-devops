### 10. How to install `nginx` loadbalancer?
### 10. How to modify `nginx configuration file` for load balancing?

## 10 Reverse proxy
## Reverse Proxy
In computer networks, the reverse proxy is a type of proxy server that retrieves resources from one or more servers on behalf of a client. These resources are then served to the client as if they originated from the proxy server itself.

To demonstrate the Loadbalancing we are going to use the `nginx`. 
NGINX is a free, open-source, high-performance HTTP server and reverse proxy, as well as an IMAP/POP3 proxy server. NGINX is known for its high performance, stability, rich feature set, simple configuration, and low resource consumption.

## Loadbalancing
A load balancer is a device that acts as a reverse proxy and distributes network or application traffic across a number of servers. Load balancers are used to increase capacity (concurrent users) and reliability of applications.




- 1. We have Deployed `RSVP` using the `Docker-stack` in previos section. RSVP app is running on 5000 port of both `manager` and `worker` nodes IP addresses.
- 2. Deploy the application using the `Docker Stack` on `manager` terminal.
```
$ docker stack deploy -c docker-stack.yaml myrsvpapp
Ignoring deprecated options:

expose: Exposing ports is unnecessary - services on the same network can access each other's containers on any port.

Creating network myrsvpapp_rsvpnet
Creating service myrsvpapp_mongodb
Creating service myrsvpapp_web

```
- 3. Create a new Droplet of Name `loadbalancer`. and open the terminal of `loadbalancer` and install `nginx`.
```
$ sudo apt-get update
$ sudo apt-get install nginx
```
 After installation by enter the IP address of `loadbalancer` droplet in browser and you can see that `nginx` server is running.

- 4. We have made run RSVP app on `worker` at `45.55.237.98:5000` and on `manager` at `104.131.185.248:5000`. So on `loadbalancer terminal`, lets modify `/ect/nginx/nginx.conf` as below with adding IP adress `worker` and `manager` running the RSVP app.

```
$ nano /ect/nginx/nginx.conf
```
- 5. modify nginx.conf as below. Please dont make Blind copy paste following configuration, modify `workers` amd `managers` IP address accordingly your's IP addresses.
```
user  www-data;
worker_processes  auto;

error_log  /var/log/nginx/error.log warn;
pid        /var/run/nginx.pid;


events {
    worker_connections  1024;
}


http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';

    access_log  /var/log/nginx/access.log  main;

    sendfile        on;
    #tcp_nopush     on;
    upstream myapp1 {
        server 45.55.237.98:5000;
	server 104.131.185.248:5000;
    }

    server {
        listen 80;

        location / {
            proxy_pass http://myapp1;
        }
    }
    keepalive_timeout  65;

    #gzip  on;

    include /etc/nginx/conf.d/*.conf;
}

```
- 6. Now lets reload the nginx serveice and restart it.
```
$ sudo systemctl reload nginx
$ sudo systemctl restart nginx

```
- 7. Now open the web browser and enter the IP address of `loadbalancer`. You will see RSVP application is opened in browser and get routed to both `manager` and `worker` IP address.

- 8. Lets Stop the Docker Stack. Goto terminal of `manager` node, and execute the following command.
```
$ docker stack down myrsvpapp
Removing service myrsvpapp_visualizer
Removing service myrsvpapp_web
Removing service myrsvpapp_mongodb
Removing network myrsvpapp_default
Removing network myrsvpapp_rsvpnet
```


## References

#### 1. https://www.nginx.com/resources/admin-guide/reverse-proxy/
#### 2. https://gist.github.com/soheilhy/8b94347ff8336d971ad0


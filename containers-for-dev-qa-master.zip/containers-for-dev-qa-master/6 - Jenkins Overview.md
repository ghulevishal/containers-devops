### 6.2 What is Jenkins?
### 6.2 How to install and configure jenkins on Digital ocean droplet?
### 6.3 How to create simple job on jenkins?
### 6.3 How to create and configure slave node?
### 6.3 How to run simple job on slave node?
### 6.4 How to create simple pipeline?
### 6.4 How to create pipeline with stagings?
### 6.5 How to install plugins in jenkins?

## 6.1 Jenkins Overview
Jenkins is open source Automation tool that is written in java. Jenkins is very useful in software development where the continous integration and continous delivery `(CI/CD)` of SOftware or project is neccesary. Jenkins gives the continous integration and continous delivery of project regardless of platform. You can integrate Jenkins with a number of testing and deployment technologies.
For betterment of use create droplet of `Minimum 2GB` at Digital ocean. Connect to the created droplet and please refer the `Setting up the lab` section of the course for details. 

Recomnded Configurations for jenkins are:
```
Java 8
1GB+ free memory
50GB+ free disk space
```

## 6.2 Install the Jenkins.
##### 1. Create the Droplet with name `jenkins` at digital ocean with minimum 2GB RAM
##### 2. Add the jenkins key application repository and install the jenkins by executing following commands at `jenkins` Droplet's terminal.
 ```
$ wget -q -O - https://pkg.jenkins.io/debian/jenkins.io.key | sudo apt-key add -
$ sudo sh -c 'echo deb http://pkg.jenkins.io/debian-stable binary/ > /etc/apt/sources.list.d/jenkins.list'
$ sudo apt-get update
$ sudo apt-get install jenkins
 ```
##### 3. After succesful installation open the web browser and enter your jenkin droplet's IP address and port 8080 as jenkin run on port 8080.
 
##### 4.In the web broser you will see the login window and it will ask you for Initial Admin Password. Go to termnal and enter following command you will get firts time login password. 
 
 ```
$ cat /var/lib/jenkins/secrets/initialAdminPassword

f259c829acde4f8c8f0b6e4ee677e887

 ```
##### 5. Enter this password to the jenkin page as your Initial Admin Password and you will navigate to another page

##### 6. Now select the plugins which you want to install click on `install suggested plugins` and proceed.
##### 7. Now create the user and its credentials. Click on Start jenkins.


## 6.3 Running a sample Job in jenkins.
##### 1. Goto the `Dashboard` click on `New Item` and enter the name of job as `Hello World` and choose `Freestyle Project` and clck on `OK` button.
##### 2. You have navigated to next window. undet the `Genral tab` decribe your project.
##### 3. Scroll down, in `Build` tab. Click on `Add build step` and choose `Execute shell`, In command section write down simple echo command `echo "Hello World"`.
##### 4.  Click on the `Save` option and you will navigate to another window.
##### 5. Clck on the `build now` button.  and your project building process will start. 
##### 6. In the `Build History` tab we can see our job build is succesfull or not. Click on the job and choose `Console Output` for more detailed output of the job.

![Jenkin Simple job](images/jsimple.jpg)

## 6.4 Add Slave Node in jenkins.
##### 1. In new tab of browser open `Digital Ocean` and create droplet of `2GB` ram and give name to it as `jenkins-slave`
##### 2. Goto jenkin tab in browser and Click on `Jenkins` tab i left corner and go to jenkin home page. Now click on `Manage Jenkins`now in jenkin tab Click on `Manage Nodes`.
##### 3. Click on `New Node` and give name `JenkinsSlave` and check the `Permanent Agent` and click on `Ok`
##### 4. In Navigated window fill up like this: 
- description as = `JenkinsSlave`
- # of executors = 4
- Remote root directory = `/root`
- Labels = `slave1`
- Launch method = launch Slave Agent Via SSH
-  Host = IP address of Jenkin-Slave droplet on Digital ocean.
-  click on credential `Add` and choose jenkins and create credential using the Login credetials of the `Jenkins-slave` Droplet created at digital ocean. click add and return back
- choose recetly created credential
- click on save.

![Jenkin Slave Node Configuration](images/jslavenode.jpg)

##### 5. Click On `JenkinsSlave` and again choose the `Launch agent`. It will show some error logs.
##### 6. Take SSH access of jenkins-slave droplet on your terminal and install following dependencies.

- $ sudo apt-get update
- $ sudo apt-get install default-jre

##### 7. Go back to the web browser where our jenkin tab is running we can see there that our `slave agent` is properly connected

## 6.5 Run simple job Slave Node

##### 1. Goto `Jenkins Dashboard` and click on `New Item` And give Name `Slave Job`, select a `Freestyle Project` and click on `Ok` Button.
##### 2. You have navigated to next window. undet the `Genral tab` decribe your project, and check `Restrict where this project can be run` and in label section enter the `slave1`
##### 3. Scroll down, in `Build` tab. Click on `Add build step` and choose `Execute shell`, In command section write down  command `echo "I ran on slave." > /tmp/note`.
##### 4.  Click on the Save option and you will navigate to another window.
##### 5. Clck on the `build now` button.  and your project building process is started. 
##### 6. In `Build History` tab we can see our job build is succesfull or not. Click on the job and choose `Console Output` where yu can see detailed output of job.
##### 7. Lets verify that whether job was running on slave node for that get  SSH access of jenkins-slave droplet and execute folowing command and check the output.
```
$ root@jenkins-slave:~# cat /tmp/note
I ran on slave.
```
This confirms that our job was running on the slave node.

 
## 6.6 Building a sample pipeline
##### 1. Goto `Jenkins Dashboard` and click on `New Item` And give Name `Sample Pipeline`, select a `Pipeline` and click on `Ok`.
##### 2. You have navigated to next window. undet the `Genral tab` decribe your project.
##### 3. Scroll down to the Pipeline section. In Defination choose `Pipeline script` and in further dropdownlist is there choose the `Hello World`
##### 4.  Click on the Save option and you will navigate to another window.
##### 5. Clck on the `build now` button.  and your project building process is started. 
##### 6. in `Build History` tab we can see our job build is succesfull or not. Click on the job and choose `Console Output`
##### 7. Click `Back to project` and then click on the `configure`
##### 8. Scroll down to the Pipeline section. And click on `Pipeline Syntax`.
##### 9. It will open the new  tab. And it gives syntax for pipeline scripting.
##### 10. Drop down the list and choose the `stage :Stage ` Now enter the name of stage `hello`.
##### 11. Copy that text and put in the Pipeline script as below.
```
node {
  
    stage('hello') {
    echo 'Hello World'
    }
    stage('bye') {
    echo 'bye all'
    }
   
}
```
##### 12.  Click on the Save option and you will navigate to another window.
##### 13. Clck on the `build now` button.  and your project building process is started. 
![Jenkin Simple Pipeline](images/jpipesample.jpg)

##### 14. in `Build History` tab we can see our job build is succesfull or not. Click on the job and choose `Console Output`

## 6.7 Jenkins Plugins.
##### 1. Goto the Jenkins `Dashboard`. Click on the `Manage Jenkins`.
##### 2. Click on the `Manage Plugins`. You will get navigate to the different window.
##### 3. Now click on the `Available` tab and you will see list of available plugins.
##### 4. In upper right corner in `Filter` search box, Type the name of plugin you wish to install.
##### 5. You will see the list of available and related plugins to your search. Choose the appropriate plugins and choose option `Install without restart`.
##### 6. In upper right corner there is one option `ENABLE AUTO REFRESH` click on it.

## References
#### 1. https://jenkins.io/doc/
#### 2. https://www.digitalocean.com/community/tutorials/how-to-install-java-with-apt-get-on-ubuntu-16-04

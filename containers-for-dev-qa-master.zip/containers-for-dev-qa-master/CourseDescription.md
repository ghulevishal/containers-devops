## Course Description
Containers are becoming de-facto standard to deploy applications as they very easy to use and cost effective. Containers can help everyone involved in the application life-cycle, be it Developer, QA Engineer or Operations Engineer. In this course we'll see how Develpoers and QA engineer can automate and streamline their processes with Docker. 

We'll quickly review Docker basics and then with the help of sample application we'll walk through the life-cycle of an application with Docker. In the course we'll see how how a developer working on his workstation can deploy the applciation on production with confidence. The Developer would work on his/her IDE to develop and debug the application, from which he/she would commit the code to GitHub. Once the code is committed, test cases would get triggered and if they pass the application would get deployed on staging environment. We would also see how it be extended to deploy the application on production.   

## Target Audience and what students would learn
The course is targeted to Developer and QA engineers of any stream to look at the end to end workflow of an application with Docker. In this course we'll see how :-
- we can configure our IDE (Visual Studio Code) to work with Docker
- debug applications remotely with IDE 
- to use dynamic Jenkins slaves to run our tests
- to use Jenkins for doing Continuous Integration and Deployment with Docker
- to configure Docker Swarm to deploy the applications
- to deploy applications with Docker Stack on Docker Swarm
- to make end-to-end workflow with Docker, from Dev to Production 
- Overview of Microservices 

## Prerequisites
- Access to any workstation with Linux, Mac on Windows installed on it
- Be familiar with the command line
- Working knowledge of Docker, Git, GitHub
- Basic understanding of Cloud
- Have access to a Linux server or Linux desktop/laptop, if not accessing DigitalOcean Cloud
- Basic Python knowledge but not mandatory

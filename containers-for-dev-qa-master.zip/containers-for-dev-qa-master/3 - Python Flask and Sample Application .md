### 3.1 How to install the Flask and it's dependencies?
### 3.1 How to Create and run Flask application?
### 3.2 How to pull rsvp application?
### 3.2 How to install dependecies for RSVP application?
### 3.2 How to run RSVP application?
### 3.3 What is pytest?
### 3.3 How to install pytest and mongomock?
### 3.3 How to run pytest for RSVP application


## What is Flask ?

`Flask` is a web framework which provides you the tools and libraries that help you in building a web application. You can build web applications like some web pages, a blog, a wiki or go as big as a web-based calendar application or a commercial website with the help of `Flask`. Flask is part of the categories of the micro-framework. Micro-framework are normally framework with little to no dependencies to external libraries.

#### Flask have following features.
 
 1. Flask is very extensible web framework.
 
 2. Hundreds of extensions availbel for building the application.
 
 3. Complex and Protected websites can be build easily using the Flask.
 
 4. Excellent Database libraries are available in Flask.
 
 5. Multiple and Various types of API are available to choose while building the application using the Flask.
  

## 3.1 Install the Flask and create eample using Flask.
##### 1. Before starting to build Simple Flask app you have to confirm the python requirements are installed on your system. So first install all the dependecies those are required. Open your Digital Ocean's Droplet terminal and execute following commands.
 ```
 $ apt-get install python-minimal
 $ apt update
 $ apt-get install python-pip
 $ export LC_ALL="en_US.UTF-8"
 ```
##### 2. INstall the Flask using pip.
```
$ pip install Flask==0.10.1
```
##### 3. Create the directory `flask-example` for application.
```
$ mkdir flask-example 
$ cd flask-example/
$ vim app.py
```
##### 4. In `flask-exapmle` direcory create the `app.py` as below
```
from flask import Flask
app = Flask(__name__)
import socket
name=socket.gethostname()
@app.route('/')

def hello():
    return "Hello World! from %s" % name
if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)
```
##### 5. Add the requirements libraries to `requirement.txt`
```
$ pip freeze > requirements.txt
```
##### 6. Check the content of directory
```
$ ls
app.py  requirements.txt
```
##### 7. Check the contents of `requirement.txt`

```
$ cat requirements.txt
Flask==0.10.1
itsdangerous==0.24
Jinja2==2.9.5
MarkupSafe==0.23
Werkzeug==0.11.15
```

##### 8. Run the Flask application.
```
$ python app.py
* Running on http://0.0.0.0:5000/ (Press CTRL+C to quit)
* Restarting with stat
* Debugger is active!
* Debugger pin code: 314-866-628
```
You will see your `Hello world` application is running on `5000` port of your Droplet's IP address. and you will able to see `Hello world from Host`. Stop the application by hitting  `ctrl+c` in your running terminal.


## 3.2 Learn about the sample RSVP app 

Now lets start with another example that is `RSVP` application. This application is built by using the python flask. So for better understanding of Flask, let's demonstrate the `RSVP` application.

##### 1. First clone the github directory which contains `RSVP` aplication and it's dependencies.

```
$ git clone https://github.com/cloudyuga/rsvpapp.git
$ cd rsvpapp/
```
##### 2. Check the contents of the `rsvpapp` directory.
```
$ ls
docker-compose.yml  jenkins      README.md         static
Dockerfile          jenkinsfile  requirements.txt  templates
__init__.py         LICENSE      rsvp.py           tests
```


##### 3. Install the dependencies required for `RSVP` application. Insall `mongodb` and `pymongo`. Execute following commands in terminal.
Now we need the `flask` and `pymongo` to be installed for running this rsvp.py application so let's install all dependencies and aplications first. We have already installed the flask. So we will install only `mongoDB` and `pymongo`. We are installing the `mongoDB` for `Ubuntu 16.04` So for different version of Ubuntu [Visit here](https://docs.mongodb.com/manual/tutorial/install-mongodb-on-ubuntu/).

```
$ apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv 0C49F3730359A14518585931BC711F9BA15703C6
$ echo "deb [ arch=amd64,arm64 ] http://repo.mongodb.org/apt/ubuntu xenial/mongodb-org/3.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-3.4.list

$ apt-get update
$ apt-get install -y mongodb-org
$ pip install pymongo
$ systemctl start mongod
```
##### 4. After installing all the dependencies, now we acn run the application using `python rsvp.py`

```
$ python rsvp.py
 * Running on http://0.0.0.0:5000/ (Press CTRL+C to quit)
 * Restarting with stat
 * Debugger is active!
 * Debugger pin code: 139-793-098

```
You will find that our application is running on the `5000` port of your Droplet's IP address. Go to the web browser and enter the IP address and 5000 port number. When yo want to stop the running application then do it by hitting `ctrl + c` in running terminal.


## 3.3 How to run tests with pytest
Pytest is a mature and full-featured Python testing tool that helps us in writting good python programs.
##### 1. Letscheck the contents of `rsvpapp` directory that we have cloned from `Github`.
```
$ cd rsvpapp/
$ ls
docker-compose.yml  jenkins      README.md         static
Dockerfile          jenkinsfile  requirements.txt  templates
__init__.py         LICENSE      rsvp.py           tests

$ ls tests/
__init__.py  test_rsvpapp.py

$ export LC_ALL=C
```


##### 2. Install the `pytest`.
```
$ pip install pytest

Collecting pytest
  Downloading pytest-3.0.6-py2.py3-none-any.whl (172kB)
    100% |################################| 174kB 797kB/s
Requirement already satisfied (use --upgrade to upgrade): setuptools in /usr/lib/python2.7/dist-packages (from pytest)
Collecting py>=1.4.29 (from pytest)
  Downloading py-1.4.32-py2.py3-none-any.whl (82kB)
    100% |################################| 92kB 1.3MB/s
Installing collected packages: py, pytest
Successfully installed py-1.4.32 pytest-3.0.6
You are using pip version 8.1.1, however version 9.0.1 is available.
You should consider upgrading via the 'pip install --upgrade pip' command.
```
##### 3. Install the `mongomock`

```
$ pip install mongomock

Collecting mongomock
  Downloading mongomock-3.7.0-py2.py3-none-any.whl
Collecting sentinels (from mongomock)
  Downloading sentinels-1.0.0.tar.gz
Collecting six (from mongomock)
  Downloading six-1.10.0-py2.py3-none-any.whl
Collecting mock (from mongomock)
  Downloading mock-2.0.0-py2.py3-none-any.whl (56kB)
    100% |################################| 61kB 4.0MB/s
Collecting funcsigs>=1; python_version < "3.3" (from mock->mongomock)
  Downloading funcsigs-1.0.2-py2.py3-none-any.whl
Collecting pbr>=0.11 (from mock->mongomock)
  Downloading pbr-1.10.0-py2.py3-none-any.whl (96kB)
    100% |################################| 102kB 4.1MB/s
Building wheels for collected packages: sentinels
  Running setup.py bdist_wheel for sentinels ... done
  Stored in directory: /root/.cache/pip/wheels/84/44/48/0934335a421a087b82bbb5cc3348d10fe01df73e0cdf7118b2
Successfully built sentinels
Installing collected packages: sentinels, six, funcsigs, pbr, mock, mongomock
Successfully installed funcsigs-1.0.2 mock-2.0.0 mongomock-3.7.0 pbr-1.10.0 sentinels-1.0.0 six-1.10.0
You are using pip version 8.1.1, however version 9.0.1 is available.
You should consider upgrading via the 'pip install --upgrade pip' command.
```

##### 4. Lets run the pytest and you will see output as below.

```
$ py.test

========================================================================= test session starts ==========================================================================
platform linux2 -- Python 2.7.12, pytest-3.0.6, py-1.4.32, pluggy-0.4.0
rootdir: /root/rsvpapp, inifile:
collected 6 items

tests/test_rsvpapp.py ......

======================================================================= 6 passed in 0.24 seconds =======================================================================
```










## References
#### 1. http://flask.pocoo.org/docs/0.12/tutorial/
#### 2. http://opentechschool.github.io/python-flask/core/hello-world.html
#### 3. https://docs.mongodb.com/manual/tutorial/install-mongodb-on-ubuntu/
#### 4. http://api.mongodb.com/python/current/installation.html
#### 5. http://docs.pytest.org/en/latest/

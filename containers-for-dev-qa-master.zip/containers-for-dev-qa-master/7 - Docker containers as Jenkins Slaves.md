### 7.1 How to create Docker-Jenkin-Slave Image?
### 7.2 How to add `Docker host` using `Yet Another Docker` plugins.?
### 7.2 How add Docker Host Authentication certificates?
### 7.2 How to add Docker Template using slave image?
### 7.2 How to run job on docker-slave image?
### 7.3 How to run pytest on RSVP application in `Docker-slave-image`?


## 7.1 Build and Push Docker jenkins slave image.
##### 1. Goto `Manage plugins` and install `Docker plugins`
##### 2. SSH terminal of your machine where your jenkin is running and create directory
```
$ mkdir docker-jenkins-slave
$ cd docker-jenkins-slave
$ vim Dockerfile
```
##### 3. Create Dockerfile as below.
```
FROM ubuntu:16.04
LABEL MAINTAINER Neependra Khare <neependra@cloudyuga.guru>

# Make sure the package repository is up to date.
RUN apt-get update
RUN apt-get -y upgrade
RUN apt-get install -y git

# Install a basic SSH server
RUN apt-get install -y openssh-server
RUN sed -i 's|session    required     pam_loginuid.so|session    optional     pam_loginuid.so|g' /etc/pam.d/sshd
RUN mkdir -p /var/run/sshd

# Install JDK 8 (latest edition)
RUN apt-get install -y openjdk-8-jdk
ENV JAVA_HOME /usr/lib/jvm/java-8-openjdk-amd64

#Install python related package
RUN apt-get install -y python-pip
RUN pip install virtualenv

# Add user jenkins to the image
RUN adduser --quiet jenkins
# Set password for the jenkins user (you may want to alter this).
RUN echo "jenkins:jenkins" | chpasswd

# Standard SSH port
EXPOSE 22

CMD ["/usr/sbin/sshd", "-D"]
```
##### 4. Build the image from the Dockerfile. The name of image we are creating must appropriate with your Docker hub account's username. As we are going to push the image to our Docker hub account. So image name must prefix with the username. For eg. in following example `cloudyuga` is username. This name will be replaced with your username of Docker hub.
```
$ docker build -t cloudyuga/docker-jenkins-python-slave .
```
##### 5. Push the built image to Docker hub. First login to your `Docker Hub` account. Login on terminal with your Docker hub username and password. 
```
$ docker login
$ docker push cloudyuga/docker-jenkins-python-slave
```
## 7.2 Configure Docker jenkins slave image.
Before proceed further Make sure you have installed the following plugins in your jenkins.
- Docker plugin
- Docker Slaves Plugin
- docker-build-step
- Docker Pipeline
- Docker Commons Plugin
- Yet Another Docker Plugin

If not then goto `Dashboard` > `Manage Jenkins` > `Manage Plugins`  And install all these above suggested plugins.

##### 1. Goto Jenkins `Dashboard` and click on `Manage Jenkins`.
##### 2. Goto the `Configure System` tab.
##### 3. Scroll down to the `Cloud` section and choose `Yet Another Docker` from drop down list.
##### 4. Now configure the `Yet Another Docker` section. Name of cloud must be name of Docker-machine that is `dockerhost` we have created. Please refer `Chapter 2`  `Docker Essentials` for more help related to the `Docker-machine`.
##### 5. In Docker URL give the IP address of the `Docker-Machine`. We can get IP address of Docker-machine by running the command in terminal `docker-machine env dockerhost` . If you dont have created Docker-Machine then create new one. Please refer `Chapter 2`  `Docker Essentials` for more help related to the `Docker-machine`. 
```
root@jenkins:~# docker-machine env dockerhost
export DOCKER_TLS_VERIFY="1"
export DOCKER_HOST="tcp://104.236.251.221:2376"
export DOCKER_CERT_PATH="/root/.docker/machine/machines/dockerhost"
export DOCKER_MACHINE_NAME="dockerhost"
# Run this command to configure your shell:
# eval $(docker-machine env dockerhost)
```
##### 6. Lets add the `Host Credentials` by Click on `Add` button. and choose `Jenkins` You will navigate to Jenkins Credential provider window.

- You have navigated to `Jenkins Credential provider` window. In front of `Kind` click and choose the `Docker Host Certificate Authentication` 
- Go to the Terminal and Run `docker-machine env dockerhost` and go the path where certificate resides.
- Execute `$ cat /root/.docker/machine/machines/dockerhost/key.pem` and copy the key and paste it in `Client Key` in `Jenkins Credential provider` window.
- Execute `$ cat /root/.docker/machine/machines/dockerhost/cert.pem` and copy the certificate and paste it in `Client Certificate` in `Jenkins Credential provider` window.
- Execute `$ cat /root/.docker/machine/machines/dockerhost/ca.pem` and copy the certificate and paste it in `Server CA Certificate` in `Jenkins Credential provider` window.
- In `ID` section write down `dockerhost`
- In Description section write `Docker Host Remote Connection`.
- Click on `ADD` and navigate back to `Yet Another Docker Configuration`.

##### 7. Now choose recently added credentials `dockerhost` and click on `Test Connection`.You will see your remote docker is conected.

![Test Connection](images/jenkintest.jpg)

##### 8. Click on `Add Docker Template` and fill the detail as below
- In `Docker Image Name` section give the name of slave image we have earlier created and pushed to `Docker Hub`.
- Scroll down to `Jenkins Slave Config` section and choose `Launch method` as `Docker SSH computer launcher`.
- Below that add new credentials. Choose `Username and Password` as `kind`
- In `Username` section enter `jenkins` and in `Password` section enter `jenkins`.
- Write down the `ID` and `Description`. ad click on `ADD`. You will navigated back to `Docker Template`.
- Under `Jenkins Slave Config` Enter label as `docker-jenkins-slave`
![Credentials](images/docker-jenkin-slave.jpg)

- Choose recently created credentials 
- click on `Save` and save the configuration.


## 7.3 Run a simple job using `Docker jenkins slave image`.

##### 1. Goto the `Dashboard` and click on `New item`. Enter the name of Job `Test Docker Jenkins Slave`
##### 2. You have navigated to next window. undet the `Genral` tab decribe your project, and check `Restrict where this project can be run` and in label section enter the lable you have given to your slave docker, as we have given `docker-jenkins-slave` so choose this name in Label Expression.

##### 3. Scroll down, in Build tab. Click on Add build step and choose Execute shell, In command section write down command
```
echo "Hello from Jenkins slave"
sleep 20
```
##### 4. Click on the `Save` option and you will navigate to another window.

##### 5. Click on the `build now` button. and your project building process is started.

##### 6. In Build History tab Click on the job and choose `Console Output`, here we can see our job build is succesfull or not.
![Docker Jenkins Slave Build Output](images/jenkins-slave-output.jpg)
##### 7. Get ssh access of the `dockerhost` Docker-machine and in terminal we can see that our container is running.
![Docker Jenkins Slave container](images/jenkinslave.jpg)

## 7.4 Run pytest on RSVP application using `Docker jenkins slave image`.

##### 1. Goto the `Dashboard` and click on `Manage Jenkins`. And Goto `System Configuration`.
##### 2. In `System Configuration` Goto the `Shell` and in `Shell Executable` insert `/bin/bash` 
##### 3. Click on `Save` button and go bach to `Dashboard`.
##### 4. Click on `New item`. Enter the name of Job `TestRSVP` choose `Freestyle Project` and click on `OK` button.
##### 5. You will Navigate to next window. Describe your project in `Description` section. check `Restrict where this project can be run` and in label section enter the lable you have given to your slave docker.
##### 6. In `Source Code Management` section click on the `Git` and repository Git URL of our `RSVP app`, `https://github.com/cloudyuga/rsvpapp.git`
##### 7. Scroll down, in `Build` tab. Click on Add build step and choose `Execute shell`, In command section write down command
```
virtualenv rsvpapp --system-site-packages -v
source rsvpapp/bin/activate
pip install -r requirements.txt
pytest tests/test_rsvpapp.py
```
##### 8. Click on the `Save` option and you will navigate to another window.

##### 9. Clck on the `build now` button. and your project building process is started.

##### 10. In Build History tab Click on the job and choose `Console Output`, here we can see our job build is succesfull or not , we can see successful result of pytest.

## Intro to Microservices 

## Monolith vs Microservice 

## 12 factor app 

## Challenges with Microservices

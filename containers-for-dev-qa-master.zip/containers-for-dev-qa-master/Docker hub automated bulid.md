## Automated builds in Docker.
Automated Builds are one of the best features of the Docker Hub. They allow you to automatically re-create your Docker images on source repository push
and Docker Cloud can automatically build images from source code in an external repository and automatically push the built image to your Docker 
repositories. The Docker Cloud can use containers to automatically test changes to the source code repository. You can enable automatic testing on any 
Docker Cloud repository to run a test on each pull request from the source code repository to create a continuous integration test service.

## References
#### 1. https://docs.docker.com/docker-cloud/builds/automated-build/
